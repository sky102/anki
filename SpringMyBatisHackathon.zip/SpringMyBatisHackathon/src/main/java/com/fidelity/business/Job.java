package com.fidelity.business;
//REQUIREMENT: add relevant properties based on columns from the proper table defined in HR schema 

//Product Owner has asked that this model capture the job identifier, job name and top salary only!

//NOTE:  properties names are up to you, they MUST NOT have underscores
public class Job {
	
	

	
	
}
