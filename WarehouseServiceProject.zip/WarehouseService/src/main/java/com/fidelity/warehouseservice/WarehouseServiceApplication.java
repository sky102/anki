package com.fidelity.warehouseservice;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * The Spring Boot application that launches the WarehouseService 
 * which is a RESTful web service.
 * 
 * @author ROI Instructor
 *
 */
@SpringBootApplication
// tell Spring Boot where to scan for annotated components
@ComponentScan(basePackages={"com.fidelity.integration", "com.fidelity.restservices", "com.fidelity.business.service"})
// tell MyBatis where to scan for mapping interface files
@MapperScan(basePackages="com.fidelity.integration.mapper")  
public class WarehouseServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(WarehouseServiceApplication.class, args);
	}
}
