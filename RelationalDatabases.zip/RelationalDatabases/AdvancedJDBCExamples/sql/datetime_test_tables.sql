
DROP TABLE datetimetest;

CREATE TABLE datetimetest
(
    date_test               DATE                            NULL,
    time_test               DATE                            NULL,
    datetime_test           DATE                            NULL,
    timestamp_test          TIMESTAMP                       NULL
);

-- Test data if we need it
--INSERT INTO datetimetest (
--    date_test,
--    time_test,
--    datetime_test,
--    timestamp_test
--)
--VALUES (
--    DATE '2017-12-31',
--    TO_DATE( '23:59:59', 'HH24:MI:SS' ),
--    TO_DATE( '2017-12-31 23:59:59', 'YYYY-MM-DD HH24:MI:SS' ),
--    TIMESTAMP '2017-12-31 23:59:59.123456'
--);
--
--COMMIT;

DROP TABLE timestamptest;

CREATE TABLE timestamptest
(
    timestamp_tz_test       TIMESTAMP WITH TIME ZONE        NULL,
    timestamp_local_tz_test TIMESTAMP WITH LOCAL TIME ZONE  NULL
);

-- Test data if we need it
--INSERT INTO timestamptest (
--    timestamp_tz_test,
--    timestamp_local_tz_test
--)
--VALUES (
--    TIMESTAMP '2017-12-31 23:59:59.123456 -02:00',
--    TIMESTAMP '2017-12-31 23:59:59.123456'
--);
--
--COMMIT;