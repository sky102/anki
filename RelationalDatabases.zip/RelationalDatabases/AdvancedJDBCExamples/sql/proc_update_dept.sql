CREATE OR REPLACE PROCEDURE update_dept
    (
        parm_deptno IN  dept.deptno%TYPE,
        parm_dname  OUT dept.dname%TYPE
    )
IS
BEGIN
    parm_dname := '';
    
    UPDATE dept
    SET    dname = 'NEW ' || dname
    WHERE  deptno = parm_deptno;
    
    IF SQL%ROWCOUNT = 1 THEN
        SELECT dname
        INTO   parm_dname
        FROM   dept
        WHERE  deptno = parm_deptno;
    END IF;
END;
/
