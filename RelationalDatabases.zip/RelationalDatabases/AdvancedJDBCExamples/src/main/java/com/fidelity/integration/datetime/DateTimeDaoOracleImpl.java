package com.fidelity.integration.datetime;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Properties;
import java.util.TimeZone;

import com.fidelity.integration.DatabaseException;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;
import oracle.sql.TIMESTAMPTZ;

public class DateTimeDaoOracleImpl {
	
	public static void main(String[] args) {
		DateTimeDaoOracleImpl dao = new DateTimeDaoOracleImpl();
		
		dao.deleteDateTimeWithoutTimeZone();
		dao.setDateTimeWithoutTimeZone();
		dao.getDateTimeWithoutTimeZone();
		
		dao.getDateTimeWithoutTimeZoneLegacy();

		// By default this is commented out because time zone handling is extremely complex
//		dao.deleteDateTimeWithTimeZone();
//		dao.setDateTimeWithTimeZone();
//		dao.getDateTimeWithTimeZone();

		dao.close();
	}

	private TimeZone tzDefault;
	
	public DateTimeDaoOracleImpl() {
		tzDefault = TimeZone.getDefault();
		System.out.println("Current default timezone: " + tzDefault);
		// We can play with this. It has no effect on the non-TZ data types
//		TimeZone.setDefault(TimeZone.getTimeZone("US/Hawaii"));		
	}

	public void getDateTimeWithoutTimeZone() {
		String sql = "SELECT * FROM datetimetest";
		
		System.out.println("*** Select Without Time Zone ***");
		
		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()){
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				// Oracle DATE treated as a date
				LocalDate ld = rs.getDate("date_test").toLocalDate();
				System.out.println("Oracle DATE treated as a date: " + ld);

				// Oracle DATE treated as a time
				LocalTime lt = rs.getTime("time_test").toLocalTime();
				System.out.println("Oracle DATE treated as a time: " + lt);

				// Oracle DATE treated as a datetime (no fractional seconds)
				LocalDateTime ldt1 = rs.getTimestamp("datetime_test").toLocalDateTime();
				System.out.println("Oracle DATE treated as a datetime (no fractional seconds): " + ldt1);
				
				// Oracle TIMESTAMP treated as a datetime (fractional seconds)
				LocalDateTime ldt2 = rs.getTimestamp("timestamp_test").toLocalDateTime();
				System.out.println("Oracle TIMESTAMP treated as a datetime (fractional seconds): " + ldt2);
			}
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL query for datetimetest: " + sql, e);	
		}
		
	}

	public void setDateTimeWithoutTimeZone() {
		String sql = "INSERT INTO datetimetest ( date_test, time_test, datetime_test, timestamp_test ) VALUES (?, ?, ?, ?)";
		System.out.println("*** Insert Without Time Zone ***");
		
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			// Oracle DATE treated as a date
			LocalDate ld = LocalDate.of(2017, 12, 31);
			stmt.setDate(1, Date.valueOf(ld));

			// Oracle DATE treated as a time
			LocalTime lt = LocalTime.of(23, 59, 59);
			stmt.setTime(2, Time.valueOf(lt));

			// Oracle DATE treated as a datetime (no fractional seconds)
			LocalDateTime ldt1 = LocalDateTime.of(ld, lt);
			stmt.setTimestamp(3, Timestamp.valueOf(ldt1));

			// Oracle TIMESTAMP treated as a datetime (fractional seconds)
			LocalDateTime ldt2 = LocalDateTime.of(2017, 12, 31, 23, 59, 59, 123456000);
			stmt.setTimestamp(4, Timestamp.valueOf(ldt2));
				
			stmt.executeUpdate();
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL insert for datetimetest: " + sql, e);	
		}
	}
	
	public void deleteDateTimeWithoutTimeZone() {
		String sql = "DELETE FROM datetimetest";

		System.out.println("*** Delete Data (without time zone) ***");
		
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.executeUpdate();
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL delete for datetimetest: " + sql, e);	
		}
	}

	public void getDateTimeWithoutTimeZoneLegacy() {
		String sql = "SELECT * FROM datetimetest";
		
		System.out.println("*** Legacy date handling ***");
		
		// Reset default time zone so the dates look "right"
		TimeZone.setDefault(tzDefault);
		
		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				java.sql.Date jsd = rs.getDate("date_test");				// date only
				java.sql.Time jst = rs.getTime("time_test");				// time only
				java.sql.Timestamp ts = rs.getTimestamp("timestamp_test");	// date & time
				
				java.util.Date jud1 = new java.util.Date(jsd.getTime());	// date only, time is set to 00:00:00
				java.util.Date jud2 = new java.util.Date(jst.getTime());	// time only, date is set to 1 Jan 1970
				
				System.out.println("Using getDate(), only the date is valid: " + jud1);
				System.out.println("Using getTime(), only the time is valid: " + jud2);
				
				java.util.Date jud3 = new java.util.Date(ts.getTime());
				System.out.println("Using getTimestamp(): " + jud3);
			}
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL query for datetimetest: " + sql, e);	
		}
	}

	// Handling datetime with time zones is much harder to achieve
	public void getDateTimeWithTimeZone() {
		String sql = "SELECT * FROM timestamptest";
		
		Calendar.Builder cb = new Calendar.Builder();
		Calendar c = cb.setTimeZone(TimeZone.getTimeZone("US/Hawaii")).build();

		System.out.println("*** Select With Time Zone ***");

		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			// You can set these here, if you prefer: they will only affect TIMEZONE WITH LOCAL TIME ZONE
//			String localTimeZone = "America/New_York";
//			OracleConnection oc = (OracleConnection) conn;
//			oc.setSessionTimeZone(localTimeZone);				

			ResultSet rs = stmt.executeQuery(sql);
			OracleResultSet ors = (OracleResultSet) rs;
			while (rs.next()) {
				System.out.println("TIMESTAMP WITH TIME ZONE");
				
				// Oracle driver ignores the Calendar argument completely (can see by decompilation)
				LocalDateTime ldt = rs.getTimestamp("timestamp_tz_test", c).toLocalDateTime();
				System.out.println("Oracle driver ignores Calendar argument: " + ldt);

				// So we need to turn a LocalDateTime into a ZonedDateTime, but we have no time zone
				// There are Oracle-specific methods to handle TIMESTAMP WITH TIME ZONE
				TIMESTAMPTZ tstz = ors.getTIMESTAMPTZ("timestamp_tz_test");
				System.out.println("Time zone from TIMESTAMP WITH TIME ZONE: " + tstz.getTimeZone());
				// The timestamp value as reported by the Oracle driver is no more useful than the standard JDBC methods
				System.out.println("Timestamp value as reported by Oracle driver: " + tstz.timestampValue(conn));

				// The time zone is correct and that gives us a time zone to work with. Convert to ZoneId for compatibility with java.time
				ZoneId zi = tstz.getTimeZone().toZoneId();
				
				// toLocalDateTime/of just ignores the TZ, so it converts the timestamp (which has been moved to current
				// time zone) directly to a LocalDateTime and then just tags it with the time zone being passed in
				ZonedDateTime zdt = ZonedDateTime.of(rs.getTimestamp("timestamp_tz_test").toLocalDateTime(), zi);
				System.out.println("Timestamp converted to ZonedDateTime using of/toLocalDateTime: " + zdt);
				
				// We can see this if we switch the current time zone to something different
				// The effect here will be to convert the time to the current time zone, but mark it with the one we pass in
				TimeZone.setDefault(TimeZone.getTimeZone("US/Hawaii"));		
				zdt = ZonedDateTime.of(rs.getTimestamp("timestamp_tz_test").toLocalDateTime(), zi);
				System.out.println("Same conversion with time zone set to US/Hawaii: " + zdt);

				// toInstant/ofInstant respects the TZ, adjusting the instant to the required time zone
				zdt = ZonedDateTime.ofInstant(rs.getTimestamp("timestamp_tz_test").toInstant(), zi);
				System.out.println("Timestamp correctly converted using ofInstant/toInstant: " + zdt);
				
				System.out.println("TIMESTAMP WITH LOCAL TIME ZONE");

				// Can experiment with setting default time zone here
//				TimeZone.setDefault(tzDefault);		

				// TIMESTAMP WITH LOCAL TIME ZONE is converted using the time zone of the session (current zone unless we change it)
				ldt = rs.getTimestamp("timestamp_local_tz_test").toLocalDateTime();
				System.out.println("TIMESTAMP WITH LOCAL TIME ZONE is converted using current timezone ("
						+ TimeZone.getDefault().getID() + "): " + ldt);

				// In the Oracle driver, we can use dedicated function to set the session time zone
				String localTimeZone = "America/Los_Angeles";
				OracleConnection oc = (OracleConnection) conn;
				oc.setSessionTimeZone(localTimeZone);	
				System.out.println("Set session time zone to " + localTimeZone);
				
				// Now, if we use the special Oracle method, we can see the time zone is that of the session
				tstz = ors.getTIMESTAMPTZ("timestamp_local_tz_test");
				System.out.println("Time zone retrieved by Oracle driver: " + tstz.getTimeZone());
				// But this converts using the default time zone
				System.out.println("Timestamp value retrieved by Oracle driver: " + tstz.timestampValue(conn));

				// And we can convert this using the same mechanism as before
				zdt = ZonedDateTime.ofInstant(rs.getTimestamp("timestamp_local_tz_test").toInstant(), tstz.getTimeZone().toZoneId());
				System.out.println(zdt);

				// But, since we set the session time zone, we already know what it is and can use that instead
				zdt = ZonedDateTime.ofInstant(rs.getTimestamp("timestamp_local_tz_test").toInstant(), ZoneId.of(localTimeZone));
				System.out.println(zdt);

				// The real class for handling TIMESTAMP WITH LOCAL TIME ZONE is this one, but it gives no way to find the
				// session time zone, so all conversions are done using the default time zone
//				TIMESTAMPLTZ tsltz = ors.getTIMESTAMPLTZ("timestamp_local_tz_test");
			}
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL query for timestamptest: " + sql, e);	
		}
	}
	
	public void setDateTimeWithTimeZone() {
		String sql = "INSERT INTO timestamptest ( timestamp_tz_test, timestamp_local_tz_test ) VALUES (?, ?)";
		

		System.out.println("*** Insert With Time Zone ***");
		
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql);
			OraclePreparedStatement ops = (OraclePreparedStatement) stmt) {

			LocalDateTime ldt = LocalDateTime.of(2017, 12, 31, 23, 59, 59);
			ZonedDateTime zdt = ZonedDateTime.ofLocal(ldt, ZoneId.of("GMT-02:00"), ZoneOffset.UTC);
			System.out.println("This is the ZonedDateTime we wish to save: " + zdt);
			
			// This calendar object has the time zone of the ZonedDateTime (GMT-2)
			Calendar cZdt = new Calendar.Builder().setTimeZone(TimeZone.getTimeZone(zdt.getZone())).build();
			
			// Can use Oracle specific methods to check session time zone
			OracleConnection oc = (OracleConnection) conn;
			System.out.println("Session time zone and offset:" + oc.getSessionTimeZone() + ", " + oc.getSessionTimeZoneOffset());

			// Current default time zone
			System.out.println("Current default time zone: " + TimeZone.getDefault());

			// If we convert to LocalDateTime, time zone is ignored
			ldt = zdt.toLocalDateTime();
			System.out.println("Converted to LocalDateTime, time zone ignored: " + ldt);

			// If we convert to Instant, time zone is respected
			Instant is = zdt.toInstant();
			System.out.println("Converted to Instant, time zone respected: " + is);

			// Converted to Instant, default time zone is applied
			Timestamp ts = Timestamp.from(is);
			System.out.println("Converted to Timestamp, default time zone is applied: " + ts);
			
			// We should really convert the timestamps using the zone of the ZonedDateTime
			TIMESTAMPTZ tstz1 = new TIMESTAMPTZ(conn, ts, cZdt);
			
			/*
			 * The first field (timestamp_tz_test) is TIMESTAMP WITH TIME ZONE. It stores the converted ZonedDateTime correctly
			 * (with time zone) if it is converted using the time zone of the original ZonedDateTime
			 * 
			 * The second field (timestamp_local_tz_test) is TIMESTAMP WITH LOCAL TIME ZONE. It strips away the time zone. The
			 * value that is stored is the real timestamp value (01-DEC-17 23.59.59 GMT-2) converted to the time zone of the server.
			 * 
			 * Instead of storing this value, I have chosen to strip out the time zone completely by storing the LocalDateTime
			 */
			ops.setTIMESTAMPTZ(1, tstz1);
			stmt.setTimestamp(2, Timestamp.valueOf(ldt));
				
			stmt.executeUpdate();
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL insert for timestamptest: " + sql, e);	
		}
		
	}

	public void deleteDateTimeWithTimeZone() {
		String sql = "DELETE FROM timestamptest";

		System.out.println("*** Delete Data (with time zone) ***");
		
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.executeUpdate();
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL delete for timestamptest: " + sql, e);	
		}
	}

	
	private Connection conn;

	private Connection getConnection() {
		if (conn == null) {
			try {
				Properties properties = new Properties();
				properties.load(this.getClass().getClassLoader()
						.getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");
				
				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException | SQLException ex) {
				throw new DatabaseException("Cannot connect", ex);
			}
		}
		return conn;
	}
	

	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}

}
