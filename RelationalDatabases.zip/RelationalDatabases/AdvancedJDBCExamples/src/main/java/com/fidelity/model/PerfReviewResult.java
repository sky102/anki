package com.fidelity.model;

public enum PerfReviewResult {
	ABOVE(1),
	AVERAGE(2),
	BELOW(3);
	
	private int code;
	
	private PerfReviewResult(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public static PerfReviewResult of(int code) {
		for (PerfReviewResult prr: values()) {
			if (prr.getCode() == code) {
				return prr;
			}
		}
		throw new IllegalArgumentException("Unknown code: " + code);
	}
}
