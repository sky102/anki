package com.fidelity.integration.enumeration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.fidelity.integration.DatabaseException;
import com.fidelity.model.EmployeePerfReview;
import com.fidelity.model.PerfReviewResult;

// This is provided for illustration only: normally we would use code or name, but not both
public class EmployeePerformanceReviewDaoOracleImpl {

	public List<EmployeePerfReview> getReviewsByCode() {
		String sql = "SELECT empno, perf_code FROM emp_perf";
		List<EmployeePerfReview> epr = new ArrayList<>();
		Statement stmt = null;
		
		Connection conn = getConnection();
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int empNumber = rs.getInt("empno");
				PerfReviewResult prr = PerfReviewResult.of(rs.getInt("perf_code"));
				epr.add(new EmployeePerfReview(empNumber, prr));
			}
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL query for emp_perf: " + sql, e);	
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return epr;
	}
	
	public List<EmployeePerfReview> getReviewsByName() {
		String sql = "SELECT empno, perf_name FROM emp_perf";
		List<EmployeePerfReview> epr = new ArrayList<>();
		Statement stmt = null;
		
		Connection conn = getConnection();
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int empNumber = rs.getInt("empno");
				PerfReviewResult prr = PerfReviewResult.valueOf(rs.getString("perf_name"));
				epr.add(new EmployeePerfReview(empNumber, prr));
			}
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL query for emp_perf: " + sql, e);	
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return epr;
	}
	
	private Connection conn;

	private Connection getConnection() {
		if (conn == null) {
			try {
				Properties properties = new Properties();
				properties.load(this.getClass().getClassLoader()
						.getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");
				
				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException | SQLException e) {
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}
	
	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}

	public void insertReview(EmployeePerfReview epr) {
		String sql = "INSERT INTO emp_perf (empno, perf_code, perf_name) VALUES (?, ?, ?)";
		PreparedStatement stmt = null;

		Connection conn = getConnection();
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, epr.getEmpNumber());
			stmt.setInt(2, epr.getPrr().getCode());
			stmt.setString(3, epr.getPrr().toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL delete for emp_perf: " + sql, e);	
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public void deleteReview(int empNumber) {
		String sql = "DELETE FROM emp_perf WHERE empno = ?";
		PreparedStatement stmt = null;

		Connection conn = getConnection();
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, empNumber);
			stmt.executeUpdate();
		} catch (SQLException e) { 
			throw new DatabaseException("Cannot execute SQL delete for emp_perf: " + sql, e);	
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
