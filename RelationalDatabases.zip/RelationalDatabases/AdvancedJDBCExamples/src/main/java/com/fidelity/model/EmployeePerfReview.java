package com.fidelity.model;

public class EmployeePerfReview {

	private int empNumber;
	private PerfReviewResult prr;

	public EmployeePerfReview(int empNumber, PerfReviewResult prr) {
		super();
		this.empNumber = empNumber;
		this.prr = prr;
	}

	public int getEmpNumber() {
		return empNumber;
	}

	public PerfReviewResult getPrr() {
		return prr;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + empNumber;
		result = prime * result + ((prr == null) ? 0 : prr.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeePerfReview other = (EmployeePerfReview) obj;
		if (empNumber != other.empNumber)
			return false;
		if (prr != other.prr)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EmployeePerformanceReview [empNumber=" + empNumber + ", prr=" + prr + "]";
	}
	
}
