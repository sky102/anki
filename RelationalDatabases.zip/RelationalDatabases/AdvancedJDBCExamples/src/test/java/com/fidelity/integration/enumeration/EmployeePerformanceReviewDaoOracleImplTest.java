package com.fidelity.integration.enumeration;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.EmployeePerfReview;
import com.fidelity.model.PerfReviewResult;

// This is provided for illustration only: normally we would use code or name, but not both
class EmployeePerformanceReviewDaoOracleImplTest {

	private EmployeePerformanceReviewDaoOracleImpl dao;
	private EmployeePerfReview expected;
	
	@BeforeEach
	void setUp() {
		dao = new EmployeePerformanceReviewDaoOracleImpl();
		expected = new EmployeePerfReview(7369, PerfReviewResult.ABOVE);
	}

	@AfterEach
	void tearDown() {
		dao.close();
	}
	
	@Test
	void testGetReviewByCode() {
		List<EmployeePerfReview> epr = dao.getReviewsByCode();
		assertTrue(epr.contains(expected));
	}

	@Test
	void testGetReviewByName() {
		List<EmployeePerfReview> epr = dao.getReviewsByName();
		assertTrue(epr.contains(expected));
	}

	@Test
	void testInsertReview() {
		EmployeePerfReview expected2 = new EmployeePerfReview(7782, PerfReviewResult.AVERAGE);
		List<EmployeePerfReview> epr = dao.getReviewsByName();
		assertFalse(epr.contains(expected2), "Should not contain new value before insert (by name)");
		epr = dao.getReviewsByCode();
		assertFalse(epr.contains(expected2), "Should not contain new value before insert (by code)");
		dao.insertReview(expected2);
		epr = dao.getReviewsByName();
		assertTrue(epr.contains(expected2), "Should contain new value after insert (by name)");
		epr = dao.getReviewsByCode();
		assertTrue(epr.contains(expected2), "Should contain new value after insert (by code)");
		dao.deleteReview(7782);
		epr = dao.getReviewsByName();
		assertFalse(epr.contains(expected2), "Should not contain new value after delete (by name)");
		epr = dao.getReviewsByCode();
		assertFalse(epr.contains(expected2), "Should not contain new value after delete (by code)");
		assertTrue(epr.contains(expected), "Should still contain expected value");
	}

}
