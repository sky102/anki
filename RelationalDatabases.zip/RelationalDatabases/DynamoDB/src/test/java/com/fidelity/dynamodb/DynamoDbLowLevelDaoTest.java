package com.fidelity.dynamodb;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Music;

class DynamoDbLowLevelDaoTest {
	DynamoDbDao dao;
	
	@BeforeEach
	void setUp() {
		dao = new DynamoDbLowLevelDao();
		dao.deleteTable(true);
		dao.createTable();
	}

	@Test
	void testCreateTable() {
		assertTrue(dao.checkTableExists());
	}
	
	@Test
	void testInsertData() throws Exception {
		List<Music> music = normalInsertForTests();
		Music track = dao.getMusicByKey(music.get(0).getArtist(), music.get(0).getTrackTitle());
		assertEquals(music.get(0), track);
	}

	@Test
	void testInsertDataByRequest() throws Exception {
		JsonTestUtils utils = new JsonTestUtils();
		List<Music> music = utils.loadData("music.json");
		for (Music track : music) {
			dao.putItemExtended(track);
			// load it twice just as an example, so there is something to see in the response
			dao.putItemExtended(track);
		}
		List<Music> results = dao.getAllMusic();
		assertEquals(3, results.size());
		assertTrue(results.contains(music.get(0)));
	}

	@Test
	void testScan() throws Exception {
		List<Music> music = normalInsertForTests();
		List<Music> results = dao.getThreeMinuteTracks();
		assertEquals(1, results.size());
		assertTrue(results.contains(music.get(1)));
	}

	@Test
	void testQuery() throws Exception {
		List<Music> music = normalInsertForTests();
		List<Music> results = dao.queryMusicByArtist(music.get(0).getArtist());
		assertEquals(2, results.size());
		assertTrue(results.contains(music.get(0)));
		assertTrue(results.contains(music.get(1)));
	}

	private List<Music> normalInsertForTests() throws Exception {
		JsonTestUtils utils = new JsonTestUtils();
		List<Music> music = utils.loadData("music.json");
		for (Music track : music) {
			dao.putItem(track);
		}
		// Guard assertion to check that file was mapped correctly
		assertTrue(music.contains(new Music("Marisa Monte", "Amor I Love You", 
				"Memorias, Cronicas e Declaracoes de Amor", 2000, 191, 
				Arrays.asList("MPB", "Pop Rock"), true)));
		return music;
	}

}
