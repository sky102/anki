package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Department;

class DepartmentDaoHsqldbImplTest {


	private DepartmentDao dao;
	
	@BeforeEach
	void setUp() {
		dao = new DepartmentDaoHsqldbImpl();
	}
	
	@AfterEach
	void tearDown() {
		dao.close();
	}
	
	@Test()
	void testQueryAllDepartments() {
		assertThrows(UnsupportedOperationException.class, () -> {
			Department expected = new Department(20, "RESEARCH", "DALLAS");
			List<Department> depts = dao.queryAllDepartments();
			assertEquals(4, depts.size(), "Should be 4 departments");
			assertTrue(depts.contains(expected), "Should contain RESEARCH");
		});
	}
	
	@Test
	void testInsert() {
		assertThrows(UnsupportedOperationException.class, () -> {
			Department dept90 = new Department(90, "NEW RESEARCH", "CARY");
			List<Department> depts = dao.queryAllDepartments();
			assertFalse(depts.contains(dept90), "Should not contain new dept before insert");
			assertEquals(4, depts.size(), "Should be 4 records before insert");
			dao.addNewDepartment(dept90);
			depts = dao.queryAllDepartments();
			assertTrue(depts.contains(dept90), "Should contain new dept after insert");
			assertEquals(5, depts.size(), "Should be 5 records after insert");
			dao.deleteDepartment(90);
			depts = dao.queryAllDepartments();
			assertFalse(depts.contains(dept90), "Should not contain new dept after reset");
			assertEquals(4, depts.size(), "Should be 4 records after insert");
		});
	}

	@Test
	void testUpdate() {
		assertThrows(UnsupportedOperationException.class, () -> {
			Department dept10 = new Department(10, "ACCOUNTING", "NEW YORK");
			Department new10 = new Department(10, "NEW ACCOUNTING", "CARY");
			Department dept30 = new Department(30, "SALES", "CHICAGO");

			// already have tests that check data before the update

			dao.updateDepartment(new10);
			List<Department> depts = dao.queryAllDepartments();
			assertTrue(depts.contains(new10), "dept 10 after update");
			assertTrue(depts.contains(dept30), "dept 30 unchanged");
			assertEquals(4, depts.size(), "Should be 4 records after update");

			dao.updateDepartment(dept10);
			depts = dao.queryAllDepartments();
			assertTrue(depts.contains(dept10), "dept 10 after reset");
			assertEquals(4, depts.size(), "Should be 4 records after reset");
		});
	}

	@Test
	void testUpdateInBatch() {
		assertThrows(UnsupportedOperationException.class, () -> {
			List<Department> updates = new ArrayList<>();
			Department expected1 = new Department(10, "NEW ACCOUNTING", "CARY");
			Department expected2 = new Department(20, "NEW RESEARCH", "CARY");
			updates.add(expected1);
			updates.add(expected2);
			Department expected3 = new Department(30, "SALES", "CHICAGO");

			List<Department> depts = dao.queryAllDepartments();
			assertFalse(depts.contains(expected1), "Should not contain new dept 10 before update");
			assertFalse(depts.contains(expected2), "Should not contain new dept 20 before update");
			assertTrue(depts.contains(expected3), "Should contain existing dept 30 before update");
			assertEquals(4, depts.size(), "Should be 4 records before update");

			dao.updateInBatch(updates);
			depts = dao.queryAllDepartments();
			assertTrue(depts.contains(expected1), "Should contain new dept 10 after update");
			assertTrue(depts.contains(expected2), "Should contain new dept 20 after update");
			assertTrue(depts.contains(expected3), "Should contain existing dept 30 after update");
			assertEquals(4, depts.size(), "Should be 4 records after update");

			Department dept10 = new Department(10, "ACCOUNTING", "NEW YORK");
			Department dept20 = new Department(20, "RESEARCH", "DALLAS");
			updates.clear();
			updates.add(dept10);
			updates.add(dept20);
			dao.updateInBatch(updates);
			depts = dao.queryAllDepartments();
			assertTrue(depts.contains(dept10), "Should contain old dept 10 after reset");
			assertTrue(depts.contains(dept20), "Should contain old dept 20 after reset");
			assertFalse(depts.contains(expected1), "Should not contain new dept 10 after reset");
			assertEquals(4, depts.size(), "Should be 4 records after update");
		});
	}

	@Test
	void testUpdateByProc() {
		assertThrows(UnsupportedOperationException.class, () -> {
			Department old1 = new Department(10, "ACCOUNTING", "NEW YORK");
			Department expected1 = new Department(10, "NEW ACCOUNTING", "NEW YORK");
			Department expected3 = new Department(30, "SALES", "CHICAGO");

			List<Department> depts = dao.queryAllDepartments();
			assertTrue(depts.contains(old1), "Should contain existing 10 before update");
			assertTrue(depts.contains(expected3), "Should contain existing dept 30 before update");
			assertEquals(4, depts.size(), "Should be 4 records before update");

			dao.updateByProcedure(10);
			depts = dao.queryAllDepartments();
			assertTrue(depts.contains(expected1), "Should contain new dept 10 after update");
			assertTrue(depts.contains(expected3), "Should contain existing dept 30 after update");
			assertEquals(4, depts.size(), "Should be 4 records after update");

			// reset data
			dao.updateDepartment(old1);
		});
	}

}
