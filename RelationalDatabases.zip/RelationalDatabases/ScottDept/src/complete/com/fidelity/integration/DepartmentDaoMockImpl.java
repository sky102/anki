package com.fidelity.integration;

import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.List;

import com.fidelity.model.Department;

public class DepartmentDaoMockImpl implements DepartmentDao {

	private List<Department> database;
	
	public DepartmentDaoMockImpl() {
		database = new ArrayList<>();
		resetDatabase();
	}
	
	private void resetDatabase() {
		database.clear();
		database.add(new Department(10, "ACCOUNTING", "NEW YORK"));
		database.add(new Department(20, "RESEARCH", "DALLAS"));
		database.add(new Department(30, "SALES", "CHICAGO"));
		database.add(new Department(40, "OPERATIONS", "BOSTON"));
		
	}

	@Override
	public List<Department> queryAllDepartments() {
		return database;
	}

	@Override
	public void addNewDepartment(Department dept) {
		database.add(dept);
	}
	
	// etc


	@Override
	public void close() {
		// do nothing
	}

	@Override
	public void rollbackSavepointTransaction(Savepoint savepoint) {
		// optionally, could check the savepoint
		resetDatabase();
	}

	@Override
	public Savepoint beginSavepointTransaction(String name) {
		// do nothing
		return null;
	}

	@Override
	public void rollbackTransaction() {
		resetDatabase();
	}

	@Override
	public void beginTransaction() {
		// do nothing
	}

	@Override
	public void deleteDepartment(int deptNumber) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public void updateInBatch(List<Department> depts) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public String updateByProcedure(int deptNumber) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public void updateDepartment(Department dept) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public List<Department> queryDepartmentsByName(String name) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public List<Department> queryDepartmentsByNameSimpler(String name) {
		throw new UnsupportedOperationException();		
	}


}
