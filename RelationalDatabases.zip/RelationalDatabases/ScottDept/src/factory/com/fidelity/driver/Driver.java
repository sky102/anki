package com.fidelity.driver;

import java.util.List;

import com.fidelity.integration.DepartmentDao;
import com.fidelity.integration.DepartmentDaoFactory;
import com.fidelity.model.Department;

public class Driver {

	public static void main(String[] args) {
		Driver driver = new Driver();
		driver.startApplication();
	}

	// This just illustrates how you might use the factory outside a test
	private void startApplication() {
		DepartmentDao dao = DepartmentDaoFactory.getDepartmentDao();
		System.out.println("Got DAO: " + dao);
		List<Department> depts = dao.queryAllDepartments();
		for (Department dept: depts) {
			System.out.println(dept);
		}
	}
	
}
