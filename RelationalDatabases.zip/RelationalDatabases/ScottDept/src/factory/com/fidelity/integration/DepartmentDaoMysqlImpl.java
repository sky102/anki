package com.fidelity.integration;

import java.sql.Savepoint;
import java.util.List;

import com.fidelity.model.Department;

public class DepartmentDaoMysqlImpl implements DepartmentDao {

	@Override
	public void close() {
		// Do nothing
	}

	@Override
	public void rollbackSavepointTransaction(Savepoint savepoint) {
		// Do nothing
	}

	@Override
	public Savepoint beginSavepointTransaction(String name) {
		// Do nothing
		return null;
	}

	@Override
	public void rollbackTransaction() {
		// Do nothing
	}

	@Override
	public void beginTransaction() {
		// Do nothing
	}

	@Override
	public List<Department> queryAllDepartments() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void addNewDepartment(Department dept) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void deleteDepartment(int deptNumber) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void updateInBatch(List<Department> depts) {
		throw new UnsupportedOperationException();
	}

	@Override
	public String updateByProcedure(int deptNumber) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void updateDepartment(Department dept) {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<Department> queryDepartmentsByName(String name) {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<Department> queryDepartmentsByNameSimpler(String name) {
		throw new UnsupportedOperationException();
	}

}
