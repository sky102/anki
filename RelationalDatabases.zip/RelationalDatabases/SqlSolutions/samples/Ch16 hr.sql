
UPDATE employees
SET    job_id = 'IT_PROG'
WHERE  employee_id = 171;

CREATE OR REPLACE TRIGGER trig_region_delete
BEFORE DELETE 
ON regions
BEGIN
    IF TO_CHAR(SYSDATE, 'HH24MI') NOT BETWEEN '0900' AND '1700' THEN
        RAISE_APPLICATION_ERROR(-20100, 'Not allowed to delete a region now');
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trig_region_delete_row
AFTER DELETE 
ON regions
FOR EACH ROW
BEGIN
    IF (:OLD.location LIKE 'Europe%' 
            AND TO_CHAR(SYSDATE, 'HH24MI') NOT BETWEEN '0100' AND '0900')
        OR (:OLD.location LIKE 'US%' 
            AND TO_CHAR(SYSDATE, 'HH24MI') NOT BETWEEN '0900' AND '1700') THEN
        RAISE_APPLICATION_ERROR(-20100, 'Not allowed to delete a region now');
    END IF;
END;
/

CREATE OR REPLACE TRIGGER trig_employee_update
BEFORE UPDATE OF sal
ON emp
FOR EACH ROW
BEGIN
    IF :NEW.sal < :OLD.sal THEN
        :NEW.comm := :NEW.sal * 0.25;
    END IF;
END;
/

-- Table doesn't exist, you will need to create it
CREATE OR REPLACE TRIGGER trig_region_del
AFTER DELETE
ON regions
FOR EACH ROW
BEGIN
    INSERT INTO region_purged (
        region_id, region_name, deleted_by, delete_date
    )
    VALUES (
        :OLD.region_id, :OLD.region_name, USER, SYSDATE
    );
END;
/


CREATE OR REPLACE TRIGGER trig_employee_delete
AFTER DELETE OR UPDATE
ON employees
BEGIN
    IF TO_CHAR(SYSDATE, 'HH24MI') > '1700' THEN
        IF DELETING THEN
            RAISE_APPLICATION_ERROR(-20100, 'Not allowed to delete an employee now');
        ELSIF UPDATING THEN
            RAISE_APPLICATION_ERROR(-20101, 'Not allowed to update an employee now');
        END IF;
    END IF;
END;
/

ALTER TRIGGER trig_employee_delete DISABLE;

ALTER TABLE employees ENABLE ALL TRIGGERS;

DROP TRIGGER trig_employee_update;

