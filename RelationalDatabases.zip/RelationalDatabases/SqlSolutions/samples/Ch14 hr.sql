
-- Procedures and Functions

CREATE OR REPLACE FUNCTION f_can_promote(
    job_id IN jobs.job_id%TYPE
) RETURN BOOLEAN
IS
    count_job NUMBER(3);
BEGIN
    SELECT COUNT(*) 
    INTO   f_can_promote.count_job
    FROM   employees e
    WHERE  e.job_id = f_can_promote.job_id;

    RETURN (count_job < 5);
END;
/

CREATE OR REPLACE PROCEDURE p_change_job(
    job_id      IN jobs.job_id%TYPE,
    employee_id IN employees.employee_id%TYPE
)
IS
BEGIN
    IF f_can_promote(p_change_job.job_id) THEN 
        UPDATE employees e
        SET    e.job_id      = p_change_job.job_id
        WHERE  e.employee_id = p_change_job.employee_id;
    END IF;
END;
/

BEGIN
    p_change_job('IT_PROG', 171);
END;
/

BEGIN
    p_change_job(job_id => 'IT_PROG',
                 employee_id => 171);
END;
/

CREATE OR REPLACE PROCEDURE p_change_job(
    job_id      IN jobs.job_id%TYPE := 'IT_PROG',
    employee_id IN employees.employee_id%TYPE
)
IS
BEGIN
    IF f_can_promote(p_change_job.job_id) THEN 
        UPDATE employees e
        SET    e.job_id      = p_change_job.job_id
        WHERE  e.employee_id = p_change_job.employee_id;
    END IF;
END;
/

BEGIN
    p_change_job(employee_id => 171);
END;
/


-- Packages

CREATE OR REPLACE PACKAGE pack_promote
IS
    PROCEDURE p_change_job(
        job_id      IN jobs.job_id%TYPE           := 'IT_PROG',
        employee_id IN employees.employee_id%TYPE
    );
END pack_promote;
/

CREATE OR REPLACE PACKAGE BODY pack_promote IS
    FUNCTION f_can_promote(
        job_id      IN jobs.job_id%TYPE
    ) RETURN BOOLEAN
    IS
        count_job NUMBER(3);
    BEGIN
        SELECT COUNT(*) 
        INTO   f_can_promote.count_job
        FROM   employees e
        WHERE  e.job_id = f_can_promote.job_id;

        RETURN (count_job < 5);
    END f_can_promote;

    PROCEDURE p_change_job(
        job_id      IN jobs.job_id%TYPE,
        employee_id IN employees.employee_id%TYPE
    )
    IS
    BEGIN
        IF f_can_promote(p_change_job.job_id) THEN 
            UPDATE employees e
            SET    e.job_id      = p_change_job.job_id
            WHERE  e.employee_id = p_change_job.employee_id;
        END IF;
    END p_change_job;
END pack_promote;
/

BEGIN
    pack_promote.p_change_job(employee_id => 171);
END;
/

BEGIN
    pack_promote.p_change_job(job_id => 'IT_PROG',
                              employee_id => 171);
END;
/
