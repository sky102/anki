CREATE OR REPLACE PACKAGE test_department_manager
IS
    --%suite(Tests for func_get_department_manager)
    
    --%test(Returns manager for a department)
    PROCEDURE manager_for_department;

    --%test(Returns null when there is no manager)
    PROCEDURE no_manager_for_department;

    --%test(Returns 0 when the department does not exist)
    PROCEDURE department_does_not_exist;

    --%test(Throws exception if department id is null)
    --%throws(-20001)
    PROCEDURE department_is_null;

END test_department_manager;
/

CREATE OR REPLACE PACKAGE BODY test_department_manager
IS
    PROCEDURE manager_for_department
    IS
    BEGIN
        ut.expect(func_get_department_manager(10)).to_equal(200);
    END manager_for_department;

    PROCEDURE no_manager_for_department
    IS
    BEGIN
        ut.expect(func_get_department_manager(120)).to_be_null();
    END no_manager_for_department;

    PROCEDURE department_does_not_exist
    IS
    BEGIN
        ut.expect(func_get_department_manager(300)).to_equal(0);
    END department_does_not_exist;

    PROCEDURE department_is_null
    IS
        result departments.manager_id%TYPE;
    BEGIN
        result := func_get_department_manager(null);
    END department_is_null;

END test_department_manager;
/

