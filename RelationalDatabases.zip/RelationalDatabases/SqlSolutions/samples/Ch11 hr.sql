
-- Aggregate Functions

SELECT job_title, min_salary 
FROM   jobs
WHERE  min_salary < 5000 
ORDER BY 
       min_salary;

-- Does not give the same results as shown on the slide
SELECT COUNT(*), COUNT(min_salary), COUNT(DISTINCT min_salary) 
FROM   jobs 
WHERE  min_salary < 5000;

SELECT COUNT(commission_pct) "Have Commission", 
       COUNT(*) - COUNT(commission_pct) "Do Not Have Commission",
       COUNT(*) "Total Emps"
FROM   employees;

SELECT SUM(commission_pct)                                   AS sum, 
       COUNT(commission_pct)                                 AS "COUNT NOT NULL", 
       ROUND(AVG(commission_pct), 6)                         AS avg, 
       ROUND(SUM(commission_pct) / COUNT(commission_pct), 6) AS "AVG BY CALC",
       COUNT(*)                                              AS count,
       ROUND(AVG(COALESCE(commission_pct, 0)), 6)            AS "AVG (NULL=0)",
       ROUND(SUM(commission_pct) / COUNT(*), 6)              AS "AVG BY CALC (NULL=0)" 
FROM   employees;

SELECT MAX(commission_pct), MIN(commission_pct) 
FROM   employees;

SELECT MAX(last_name) FROM employees;

SELECT MIN(hire_date) FROM employees;

-- This one errors
SELECT job_title, MAX(min_salary) FROM jobs
WHERE  min_salary < 5000;


-- GROUP BY

SELECT AVG(min_salary), AVG(max_salary), COUNT(*) 
FROM   jobs
WHERE  SUBSTR(job_id, 1, 2) = 'AD';

SELECT AVG(min_salary), AVG(max_salary), COUNT(*) 
FROM   jobs
WHERE  SUBSTR(job_id, 1, 2) = 'FI';

-- Not in the course material, but this is the natural implementation of the
-- GROUP BY that is done manually in the previous queries
SELECT SUBSTR(job_id, 1, 2) AS "Job Family", AVG(min_salary), AVG(max_salary), COUNT(*) 
FROM   jobs
GROUP BY 
       SUBSTR(job_id, 1, 2)
ORDER BY
       SUBSTR(job_id, 1, 2);


SELECT department_id, MIN(employee_id), MAX(employee_id)
FROM   employees
WHERE  department_id > 10
GROUP BY department_id
ORDER BY department_id;

SELECT department_id, COUNT(*), MIN(employee_id), MAX(employee_id)              
FROM   employees
GROUP BY 
       department_id
ORDER BY 
       COUNT(*) DESC, department_id DESC NULLS LAST;


-- HAVING

SELECT department_id, COUNT(*), MIN(employee_id), MAX(employee_id)
FROM   employees
GROUP BY 
       department_id
HAVING COUNT(*) > 5
ORDER BY 
       COUNT(*) DESC, department_id DESC NULLS LAST;

-- Invalid WHERE clause
SELECT department_id, COUNT(*), MIN(employee_id), MAX(employee_id)
FROM   employees
WHERE  COUNT(*) > 5
GROUP BY 
       department_id
ORDER BY 
       COUNT(*) DESC, department_id DESC NULLS LAST;

-- Legal but inefficient
SELECT department_id, COUNT(*), MIN(employee_id), MAX(employee_id)
FROM   employees
GROUP BY 
       department_id
HAVING COUNT(*) > 5
AND    department_id <> 100
ORDER BY 
       COUNT(*) DESC , department_id DESC NULLS LAST;

-- Better
SELECT department_id, COUNT(*), MIN(employee_id), MAX(employee_id)
FROM   employees
WHERE  department_id <> 100
GROUP BY 
       department_id
HAVING COUNT(*) > 5
ORDER BY 
       COUNT(*) DESC , department_id DESC NULLS LAST;


-- Subqueries

SELECT e.last_name, e.first_name, e.salary
FROM   employees e
WHERE  e.salary = (
    SELECT MAX(e2.salary)
    FROM   employees e2
);

-- But this doesn't return anything since Smith's manager doesn't manage any departments
SELECT department_id, department_name
FROM   departments
WHERE  manager_id IN (
    SELECT manager_id
    FROM   employees
    WHERE  last_name = 'Smith'
);

-- But Zlotkey's does
SELECT department_id, department_name
FROM   departments
WHERE  manager_id IN (
    SELECT manager_id
    FROM   employees
    WHERE  last_name = 'Zlotkey'
);

SELECT d.department_name
FROM   departments d
WHERE  NOT EXISTS (
    SELECT 1
    FROM employees e
    WHERE e.department_id = d.department_id
);
