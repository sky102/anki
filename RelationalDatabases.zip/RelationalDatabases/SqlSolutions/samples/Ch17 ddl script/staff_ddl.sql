
CREATE TABLE staff (
    client_ID         NUMBER(5) NOT NULL
  , client_name       VARCHAR2(20)
  , client_address    VARCHAR2(40)
  , client_type       NUMBER(2) DEFAULT 01
  , client_industry   VARCHAR2(25)
  , client_start_date DATE
);
