
-- Sequences

CREATE SEQUENCE seq_emp
INCREMENT BY 1
START WITH 8000;

INSERT INTO emp (empno, ename)
VALUES (seq_emp.NEXTVAL,'CHAVAS');

SELECT empno, ename FROM emp WHERE empno > 7900;

-- This could be in scott or hr, but is more "hr-like"
CREATE TABLE clients (
    client_id         NUMBER GENERATED ALWAYS AS IDENTITY
  , client_name       VARCHAR2(20)
  , client_type       NUMBER(2) DEFAULT 01
  , client_start_date DATE
);


-- Constraints

-- Suggest you avoid actually executing most of these

ALTER TABLE emp
ADD CONSTRAINT emp_pk
PRIMARY KEY (empno);

ALTER TABLE emp 
ADD CONSTRAINT emp_uk1
UNIQUE (ename, job, hiredate);

ALTER TABLE emp
ADD CONSTRAINT emp_dept_fk1
FOREIGN KEY (deptno) REFERENCES dept (deptno);

-- Careful with ON DELETE CASCADE
ALTER TABLE emp 
ADD CONSTRAINT emp_dept_fk1
FOREIGN KEY (deptno) REFERENCES dept (deptno)
ON DELETE CASCADE;

ALTER TABLE emp 
ADD CONSTRAINT emp_comm_sal_ck
CHECK (comm < sal * .10);

ALTER TABLE emp 
DROP CONSTRAINT emp_comm_sal_ck;

ALTER TABLE emp
DROP PRIMARY KEY;

ALTER TABLE emp DISABLE CONSTRAINT emp_dept_fk1;

ALTER TABLE emp ENABLE CONSTRAINT emp_dept_fk1;

SELECT constraint_name, constraint_type, status
FROM user_constraints
WHERE table_name = 'EMP';


-- Indexes

-- Again, suggest you avoid executing these

-- Will create index
ALTER TABLE emp 
ADD	CONSTRAINT emp_pk
PRIMARY KEY (empno);

-- Or, do it manually
CREATE UNIQUE INDEX emp_pk_ix 
ON emp (empno);

-- Will create index
ALTER TABLE emp 
ADD CONSTRAINT emp_uk1
UNIQUE (ename, hiredate);

-- Or, do it manually
CREATE UNIQUE INDEX emp_uk1_ix
ON emp (ename, hiredate);

CREATE INDEX emp_mgr_ix
ON emp (mgr);

DROP INDEX emp_mgr_ix;

