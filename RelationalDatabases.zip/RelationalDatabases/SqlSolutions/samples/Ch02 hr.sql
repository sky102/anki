SELECT last_name, salary, salary * 12, 'Wow', 1/8 FROM employees;

SELECT 1/8 FROM employees;

SELECT 1/8 FROM DUAL;

desc jobs

SELECT * FROM jobs;

SELECT job_title AS position, job_title AS "Position Title" 
FROM   jobs;

SELECT city, state_province, country_id 
FROM   locations;

SELECT country_id 
FROM   locations;

SELECT DISTINCT country_id 
FROM   locations;

SELECT DISTINCT country_id, city 
FROM   locations;

SELECT * 
FROM   jobs
WHERE  min_salary = 4000;

SELECT * 
FROM   jobs 
WHERE  job_title = 'Marketing Manager';

SELECT * 
FROM   jobs 
WHERE  job_title = 'MARKETING MANAGER';

SELECT * 
FROM   jobs 
WHERE  min_salary <> 4000;

SELECT * 
FROM   jobs 
WHERE  min_salary BETWEEN 3000 AND 4000;

SELECT * 
FROM   jobs 
WHERE  min_salary IN (3000, 4000);

SELECT first_name, last_name 
FROM   employees
WHERE  last_name LIKE 'P%';

SELECT * 
FROM   jobs 
WHERE  min_salary = NULL;

SELECT * 
FROM   jobs 
WHERE  min_salary <> NULL;

SELECT city, state_province, country_id 
FROM   locations
WHERE  state_province IS NULL;

SELECT * 
FROM   jobs 
WHERE  min_salary = 3000 
OR     min_salary = 4000;

SELECT * 
FROM   jobs 
WHERE  min_salary = 4000
AND    max_salary < 10000;

SELECT * 
FROM   jobs 
WHERE  NOT (
           min_salary = 4000 
       AND max_salary < 10000
       );

SELECT *
FROM   jobs
WHERE  job_title = 'Marketing Manager'
OR     min_salary = 4000
AND    max_salary < 10000 ;


SELECT * 
FROM   jobs
WHERE  (
           job_title = 'Marketing Manager'
       OR  min_salary = 4000
)
AND    max_salary < 10000 ;

SELECT job_title, max_salary 
FROM   jobs 
ORDER BY
       max_salary;

SELECT job_title, max_salary 
FROM   jobs 
ORDER BY
       max_salary DESC;

SELECT job_title, max_salary / 12 AS "Monthly Salary"
FROM   jobs
WHERE  max_salary / 12 > 1000
ORDER BY
       max_salary / 12 DESC, job_title;

SELECT job_title, max_salary / 12 AS "Monthly Salary"
FROM   jobs
WHERE  max_salary / 12 > 1000
ORDER BY
       "Monthly Salary" DESC, job_title;

SELECT job_title, max_salary / 12 AS "Monthly Salary"
FROM   jobs
WHERE  max_salary / 12 > 1000
ORDER BY 
       2 DESC, job_title;

SELECT department_name, manager_id 
FROM   departments
ORDER BY 
       manager_id;

SELECT department_name, manager_id 
FROM   departments
ORDER BY 
       manager_id DESC;
       
SELECT department_name, manager_id 
FROM   departments
ORDER BY 
       manager_id DESC  NULLS FIRST;

SELECT department_name, manager_id 
FROM   departments
ORDER BY 
       manager_id DESC  NULLS LAST;
