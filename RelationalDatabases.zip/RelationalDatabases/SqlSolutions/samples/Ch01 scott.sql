SELECT deptno, dname
FROM   dept
WHERE  loc = 'DALLAS';
