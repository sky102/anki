
CREATE OR REPLACE PROCEDURE update_emp(
    employee_id employees.employee_id%TYPE,
    last_name   employees.last_name%TYPE
)
IS
BEGIN
    UPDATE employees e
    SET    e.last_name   = update_emp.last_name
    WHERE  e.employee_id = update_emp.employee_id;
END;
/

CREATE OR REPLACE PACKAGE test_update_emp IS
    --%suite(Test the update_emp procedure)
    
    --%test(Check that one employee is updated)
    PROCEDURE update_one_employee;
END test_update_emp;
/

CREATE OR REPLACE PACKAGE BODY test_update_emp IS
    PROCEDURE update_one_employee
    IS
        test_emp_id    CONSTANT employees.employee_id%TYPE := 110;
        test_last_name CONSTANT employees.last_name%TYPE := 'Zhang';
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
        expected         SYS_REFCURSOR;
        actual           SYS_REFCURSOR;
        actual_name      employees.last_name%TYPE;
    BEGIN
        -- prepare expected and before data
        OPEN unchanged_before FOR
        SELECT *
        FROM   employees
        WHERE  employee_id != test_emp_id;

        -- It is possible to compare records, but ref cursors are easier
        OPEN expected FOR
        SELECT *
        FROM   employees
        WHERE  employee_id = test_emp_id;
        
        -- execute
        update_emp(employee_id => test_emp_id, 
                    last_name => test_last_name);
        
        -- check results
        OPEN actual FOR
        SELECT *
        FROM   employees
        WHERE  employee_id = test_emp_id;

        SELECT last_name
        INTO   actual_name
        FROM   employees
        WHERE  employee_id = test_emp_id;

        OPEN unchanged_after FOR
        SELECT *
        FROM   employees
        WHERE  employee_id != test_emp_id;

        ut.expect(actual).to_equal(expected).unordered().join_by('EMPLOYEE_ID').exclude('LAST_NAME');
        ut.expect(actual_name).to_equal(test_last_name);        
        ut.expect(unchanged_after).to_equal(unchanged_before).uc();

    END update_one_employee;
END test_update_emp;
/

BEGIN
    ut.run('test_update_emp');
END;
/

