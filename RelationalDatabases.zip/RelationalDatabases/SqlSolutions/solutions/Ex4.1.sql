-- 1
SELECT l.city,
       l.location_id,
       d.department_name
FROM   departments d
JOIN   locations   l
ON     d.location_id = l.location_id;

-- 2
SELECT c.country_name,
       l.city
FROM   locations l
JOIN   countries c
ON     l.country_id = c.country_id;

-- 3
SELECT c.country_name,
       l.city,
       d.department_name
FROM   departments d
JOIN   locations   l
ON     d.location_id = l.location_id
JOIN   countries   c
ON     l.country_id  = c.country_id;

-- 4
SELECT e.employee_id,
       e.first_name,
       e.last_name,
       jh.job_id
FROM   employees   e
JOIN   job_history jh
ON     e.employee_id = jh.employee_id
ORDER BY
       e.employee_id;

-- 5
SELECT j.job_title,
       jh.employee_id,
       jh.start_date
FROM   job_history jh
JOIN   jobs        j
ON     jh.job_id     = j.job_id
WHERE  jh.start_date > DATE '1998-01-01';

-- 6
SELECT j.job_title,
       jh.employee_id,
       jh.start_date,
       e.first_name,
       e.last_name
FROM   job_history jh
JOIN   jobs        j
ON     jh.job_id      = j.job_id
JOIN   employees   e
ON     jh.employee_id = e.employee_id;

