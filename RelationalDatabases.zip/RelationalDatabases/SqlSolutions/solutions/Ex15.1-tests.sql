CREATE OR REPLACE PACKAGE test_check_salary
IS
    --%suite(Tests for func_check_salary)
    
    --%test(Returns true if salary is in range)
    PROCEDURE salary_in_range;

    --%test(Returns false if salary is below minimum)
    PROCEDURE salary_below_minimum;

    --%test(Returns false if salary is above maximum)
    PROCEDURE salary_above_maximum;

    --%test(Checks a second job_id)
    PROCEDURE check_second_job_id;

    --%test(Throws exception for NULL job_id)
    --%throws(-20001)
    PROCEDURE exception_for_null_job_id;

    --%test(Throws exception for NULL salary)
    --%throws(-20001)
    PROCEDURE exception_for_null_salary;

    --%test(Returns false if job_id does not exist)
    PROCEDURE job_id_does_not_exist;

END test_check_salary;
/

CREATE OR REPLACE PACKAGE BODY test_check_salary
IS

    PROCEDURE salary_in_range
    IS
    BEGIN
        ut.expect(func_check_salary('AD_VP', 20000)).to_equal(TRUE);
    END salary_in_range;

    PROCEDURE salary_below_minimum
    IS
    BEGIN
        ut.expect(func_check_salary('AD_VP', 10000)).to_equal(FALSE);
    END salary_below_minimum;

    PROCEDURE salary_above_maximum
    IS
    BEGIN
        ut.expect(func_check_salary('AD_VP', 40000)).to_equal(FALSE);
    END salary_above_maximum;

    PROCEDURE check_second_job_id
    IS
    BEGIN
        ut.expect(func_check_salary('AD_ASST', 4000)).to_equal(TRUE);
    END check_second_job_id;

    PROCEDURE exception_for_null_job_id
    IS
        result BOOLEAN;
    BEGIN
        result := func_check_salary(NULL, 4000);
    END exception_for_null_job_id;

    PROCEDURE exception_for_null_salary
    IS
        result BOOLEAN;
    BEGIN
        result := func_check_salary('AD_VP', NULL);
    END exception_for_null_salary;

    PROCEDURE job_id_does_not_exist
    IS
    BEGIN
        ut.expect(func_check_salary('XX_XXX', 4000)).to_equal(FALSE);
    END job_id_does_not_exist;

END test_check_salary;
/

