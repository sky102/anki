-- 1
SELECT e.employee_id,
       e.first_name,
       e.last_name,
       jh.job_id
FROM   employees   e
LEFT OUTER JOIN
       job_history jh
ON     e.employee_id = jh.employee_id
ORDER BY
       e.employee_id;

-- 2
SELECT j.job_title,
       jh.employee_id
FROM   jobs        j
LEFT OUTER JOIN
       job_history jh
ON     j.job_id = jh.job_id;

-- 3
SELECT j.job_title,
       jh.employee_id
FROM   jobs        j
LEFT OUTER JOIN
       job_history jh
ON     j.job_id     = jh.job_id
WHERE  j.min_salary > 9000;

-- 4
SELECT j.job_title,
       jh.employee_id,
       jh.start_date
FROM   jobs        j
LEFT OUTER JOIN
       job_history jh
ON     j.job_id = jh.job_id
AND    jh.start_date > DATE '1998-01-01';

-- 5
SELECT j.job_title,
       jh.employee_id,
       jh.start_date,
       e.first_name,
       e.last_name
FROM   jobs        j
LEFT OUTER JOIN
       job_history jh
ON     j.job_id       = jh.job_id
LEFT OUTER JOIN
       employees   e
ON     jh.employee_id = e.employee_id;

-- BONUS
-- 6
SELECT j.job_title,
       jh.employee_id,
       jh.start_date,
       e.first_name,
       e.last_name
FROM   employees   e
LEFT OUTER JOIN
       job_history jh
ON     jh.employee_id = e.employee_id
LEFT OUTER JOIN
       jobs        j
ON     j.job_id       = jh.job_id;

