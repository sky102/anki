SET SERVEROUTPUT ON;

-- 1 to 6
SELECT *
FROM   employees
WHERE  last_name IN ('Austin', 'Lee', 'King');

DECLARE
    emp_rec employees%ROWTYPE;
BEGIN
    SELECT *
    INTO   emp_rec
    FROM   employees
    WHERE  last_name = 'Austin';
    
    DBMS_OUTPUT.PUT_LINE('old salary: ' || emp_rec.salary);

    IF COALESCE(emp_rec.commission_pct, 0) = 0 THEN
        emp_rec.salary := emp_rec.salary + 500;
    ELSIF emp_rec.commission_pct < 0.02 THEN
        emp_rec.salary := emp_rec.salary + 300;
    ELSE
        emp_rec.salary := emp_rec.salary + 100;
    END IF;
    
    DBMS_OUTPUT.PUT_LINE('new salary: ' || emp_rec.salary);

    UPDATE  employees
    SET     salary = emp_rec.salary
    WHERE   employee_id = emp_rec.employee_id;
END;
/

SELECT *
FROM   employees
WHERE  last_name IN ('Austin', 'Lee', 'King');

-- 8
ROLLBACK;

-- 9
DECLARE
    emp_rec employees%ROWTYPE;
BEGIN
    SELECT *
    INTO   emp_rec
    FROM   employees
    WHERE  last_name = 'Austin';
    
    DBMS_OUTPUT.PUT_LINE('old salary: ' || emp_rec.salary);

    CASE
        WHEN COALESCE(emp_rec.commission_pct, 0) = 0 THEN
            emp_rec.salary := emp_rec.salary + 500;
        WHEN emp_rec.commission_pct < 0.02 THEN
            emp_rec.salary := emp_rec.salary + 300;
        ELSE
            emp_rec.salary := emp_rec.salary + 100;
    END CASE;
   
    DBMS_OUTPUT.PUT_LINE('new salary: ' || emp_rec.salary);

    UPDATE  employees
    SET     salary = emp_rec.salary
    WHERE   employee_id = emp_rec.employee_id;
END;
/

-- 10
ROLLBACK;

-- BONUS

-- case expression, and #11, 12 (exception handling)
DECLARE
    emp_rec employees%ROWTYPE;
BEGIN
    SELECT *
    INTO   emp_rec
    FROM   employees
    WHERE  last_name = 'King';
    
    DBMS_OUTPUT.PUT_LINE('old salary: ' || emp_rec.salary);

    emp_rec.salary := emp_rec.salary +
        CASE
            WHEN COALESCE(emp_rec.commission_pct, 0) = 0 THEN
                500
            WHEN emp_rec.commission_pct < 0.02 THEN
                300
            ELSE
                100
        END;
    
    DBMS_OUTPUT.PUT_LINE('new salary: ' || emp_rec.salary);

    UPDATE  employees
    SET     salary = emp_rec.salary
    WHERE   employee_id = emp_rec.employee_id;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20999, 'Employee does not exist');
    WHEN TOO_MANY_ROWS THEN
        RAISE_APPLICATION_ERROR(-20999, 'Multiple employees found');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20999, 'Contact Support: ' || SQLERRM);
END;
/


ROLLBACK;

-- 13
SELECT *
FROM   employees
WHERE  last_name IN ( 'Austin', 'Lee', 'King', 'Smith', 'Howard' );

-- To show this could be done in a single UPDATE
UPDATE employees
SET    salary = salary +
         CASE
           WHEN COALESCE(commission_pct, 0) = 0 THEN
             500
           WHEN commission_pct < 0.02 THEN
             300
           ELSE
             100
         END
WHERE  last_name = 'Austin';

ROLLBACK;
