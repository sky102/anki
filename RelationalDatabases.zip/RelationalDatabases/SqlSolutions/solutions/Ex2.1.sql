-- 1
SELECT dname, deptno
FROM   dept;

-- 2
SELECT *
FROM   dept;

-- 3
SELECT dname  AS "Name",
       deptno AS "DEPT#",
       loc    AS "Dept Location"
FROM   dept;

-- 4
SELECT deptno
FROM   emp;

-- 5
SELECT DISTINCT deptno
FROM   emp;

-- 6
SELECT deptno, job
FROM   emp;

-- 7
SELECT DISTINCT deptno, job
FROM   emp;

-- 8
SELECT ename
FROM   emp
WHERE  deptno = 30;

-- 9
SELECT ename
FROM   emp
WHERE  hiredate = DATE '1981-12-17';

-- 10
SELECT ename
FROM   emp
WHERE  hiredate >= DATE '1981-12-17';

-- Other safe ways of specifying the date
SELECT ename
FROM   emp
WHERE  hiredate >= TO_DATE('12-17-1981', 'MM-DD-YYYY');

SELECT ename
FROM   emp
WHERE  hiredate >= TO_DATE( '19811217', 'YYYYMMDD' );

-- 11
SELECT ename
FROM   emp
WHERE  job = 'clerk';

-- 12
SELECT ename
FROM   emp
WHERE  job = 'CLERK';

-- 13
SELECT ename
FROM   emp
WHERE  sal > 2500;

-- 14
SELECT ename
FROM   emp
WHERE  sal BETWEEN 1000 AND 1600;

-- 15
SELECT ename
FROM   emp
WHERE  ename LIKE '%ER%';

-- 16
SELECT empno, ename
FROM   emp
WHERE  comm IS NULL;

-- 17
SELECT empno, ename, comm
FROM   emp
ORDER BY
       comm;

-- 18
SELECT empno, ename, comm
FROM   emp
ORDER BY
       comm DESC;

-- 19
SELECT empno, ename, comm
FROM   emp
ORDER BY
       comm DESC NULLS LAST;
