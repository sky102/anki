
--1
SELECT department_id,
       department_name
FROM   departments
WHERE  department_id IN (
         SELECT department_id
         FROM employees
       )
ORDER BY
       department_id;

--2
SELECT employee_id,
       first_name,
       last_name,
       salary
FROM   employees
WHERE  salary > (
         SELECT AVG(salary)
         FROM employees
       )
ORDER BY
       salary DESC;

--3
SELECT employee_id,
       first_name,
       last_name,
       salary
FROM   employees
WHERE  salary = (
         SELECT MAX(salary)
         FROM employees
       );

--4
SELECT employee_id,
       first_name,
       last_name,
       salary,
       commission_pct
FROM   employees
WHERE  salary > (
         SELECT AVG(salary)
         FROM employees
       )
AND    commission_pct > (
         SELECT AVG(commission_pct)
         FROM employees
       )
ORDER BY
       last_name;

-- BONUS

--5
SELECT employee_id,
       first_name,
       last_name
FROM   employees
WHERE  department_id IN (
         SELECT department_id
         FROM   departments
         WHERE location_id IN (
           SELECT location_id
           FROM   locations
           WHERE  city = 'London'
         )
       );
