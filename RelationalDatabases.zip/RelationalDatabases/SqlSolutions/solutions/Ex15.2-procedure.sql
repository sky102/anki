CREATE OR REPLACE PROCEDURE proc_update_salary(
    employee_id IN employees.employee_id%TYPE,
    salary IN employees.salary%TYPE
)
IS
    job_id employees.job_id%TYPE;
BEGIN
    -- the function already throws the exception if the salary is NULL
    IF employee_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'employee_id may not be NULL');
    END IF;

    SELECT job_id
    INTO   proc_update_salary.job_id
    FROM   employees
    WHERE  employee_id = proc_update_salary.employee_id;

    IF func_check_salary(job_id => job_id,
            salary => salary) THEN
        UPDATE employees e
        SET    salary        = proc_update_salary.salary
        WHERE  e.employee_id = proc_update_salary.employee_id;
    END IF;

-- If the employee does not exist, just ignore the error
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        NULL;
END proc_update_salary;
/
