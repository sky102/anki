
SET SERVEROUTPUT ON;

-- 1-6
CREATE OR REPLACE PROCEDURE update_emp(
    parm_employee_id IN employees.employee_id%TYPE,
    parm_last_name   IN employees.last_name%TYPE,
    parm_email       IN employees.email%TYPE,
    parm_hire_date   IN employees.hire_date%TYPE,
    parm_job_id      IN employees.job_id%TYPE,
    parm_salary      IN employees.salary%TYPE
)
IS
    emp_count NUMBER(5);
BEGIN
    UPDATE employees
    SET    salary      = parm_salary
    WHERE  employee_id = parm_employee_id
    AND    last_name   = parm_last_name
    AND    hire_date   = parm_hire_date
    AND    job_id      = parm_job_id;
    
    IF SQL%NOTFOUND THEN
    -- No row was updated. There are two possible reasons: either the
    -- details don't match, or the employee doesn't exist. It is VERY
    -- important that you do not assume the UPDATE failed just because
    -- the employee doesn't exist
    
    -- There are a number of ways to structure this code
        SELECT COUNT(*)
        INTO   emp_count
        FROM   employees
        WHERE  employee_id = parm_employee_id;
        
        IF emp_count = 0 THEN
        -- Employee doesn't exist
            INSERT INTO
                   employees (
                       employee_id,
                       last_name,
                       email,
                       hire_date,
                       job_id,
                       salary
                   )
            VALUES (
                       parm_employee_id,
                       parm_last_name,
                       parm_email,
                       parm_hire_date,
                       parm_job_id,
                       parm_salary
                   );
            DBMS_OUTPUT.PUT_LINE( 'Inserted new employee' );
        ELSE
        -- Details don't match
            DBMS_OUTPUT.PUT_LINE( 'Employee already exists, details do not match' );
        END IF;
    ELSE
        DBMS_OUTPUT.PUT_LINE( 'Employee updated' );
    END IF;
END;
/

-- 7
SELECT *
FROM   employees
WHERE  last_name IN ( 'Chen', 'Johnston' );

-- This update should succeed
BEGIN
    update_emp( 110,
                'Chen',
                'JCHEN',
                DATE '2005-09-28',
                'FI_ACCOUNT',
                2000 );
END;
/

-- This update should fail because the details don't match
BEGIN
    update_emp( 110,
                'XXXX',
                'JCHEN',
                DATE '2005-09-28',
                'FI_ACCOUNT',
                5000 );
END;
/

-- This update should insert Johnson instead
BEGIN
    update_emp( 999,
                'Johnston',
                'JJ',
                DATE '2018-06-08',
                'IT_PROG',
                20000 );
END;
/

-- 8
ROLLBACK;

-- BONUS

-- 9
DROP PROCEDURE update_emp;

-- 10-12
CREATE OR REPLACE PACKAGE pack_employee
IS
    PROCEDURE update_emp(
        parm_employee_id   IN employees.employee_id%TYPE,
        parm_last_name     IN employees.last_name%TYPE,
        parm_email         IN employees.email%TYPE,
        parm_hire_date     IN employees.hire_date%TYPE,
        parm_job_id        IN employees.job_id%TYPE,
        parm_salary        IN employees.salary%TYPE,
        parm_department_id IN employees.department_id%TYPE
    );
END pack_employee;
/

-- 13
CREATE OR REPLACE PACKAGE BODY pack_employee
IS

-- 14-16
    FUNCTION get_manager(
        parm_department_id IN employees.department_id%TYPE
    )
    RETURN NUMBER
    IS
        dept_count NUMBER(5);
        mgr_id     departments.manager_id%TYPE;
    BEGIN
        SELECT COUNT(*)
        INTO   dept_count
        FROM   departments
        WHERE  department_id = parm_department_id;
        
        -- Here we distinguish between the department not existing
        -- and there being no manager. When we use the function, we
        -- don't make that distinction, so we could simplify this.
        IF dept_count = 0 THEN
            RETURN 0;
        ELSE
            SELECT manager_id
            INTO   mgr_id
            FROM   departments
            WHERE  department_id = parm_department_id;
            
            RETURN mgr_id;
        END IF;
        
        RETURN NULL;
    END get_manager;

-- 17
    PROCEDURE update_emp(
        parm_employee_id   IN employees.employee_id%TYPE,
        parm_last_name     IN employees.last_name%TYPE,
        parm_email         IN employees.email%TYPE,
        parm_hire_date     IN employees.hire_date%TYPE,
        parm_job_id        IN employees.job_id%TYPE,
        parm_salary        IN employees.salary%TYPE,
        parm_department_id IN employees.department_id%TYPE
    )
    IS
        emp_count NUMBER(5);
    BEGIN
        UPDATE employees
        SET    salary      = parm_salary
        WHERE  employee_id = parm_employee_id
        AND    last_name   = parm_last_name
        AND    hire_date   = parm_hire_date
        AND    job_id      = parm_job_id;
        
        IF SQL%NOTFOUND THEN
            SELECT COUNT(*)
            INTO   emp_count
            FROM   employees
            WHERE  employee_id = parm_employee_id;
            
            IF emp_count = 0 THEN
            -- Don't care whether the department doesn't exist, or no manager
                IF COALESCE(get_manager(parm_department_id), 0) = 0 THEN
                    DBMS_OUTPUT.PUT_LINE('Department '
                                    || parm_department_id
                                    || ' does not exist, or has no manager');
                ELSE
                    INSERT INTO
                           employees (
                               employee_id,
                               last_name,
                               email,
                               hire_date,
                               job_id,
                               salary,
                               department_id
                           )
                    VALUES (
                               parm_employee_id,
                               parm_last_name,
                               parm_email,
                               parm_hire_date,
                               parm_job_id,
                               parm_salary,
                               parm_department_id
                           );
                    DBMS_OUTPUT.PUT_LINE('Inserted new employee');
                END IF;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Employee already exists, details do not match');
            END IF;
        ELSE
            DBMS_OUTPUT.PUT_LINE('Employee updated');
        END IF;
    END update_emp;

-- 18
END pack_employee;
/

-- 20
SELECT *
FROM   employees
WHERE  last_name IN ( 'Chen', 'Johnston' );

-- Chen, details match, update salary, success
BEGIN
    pack_employee.update_emp( 110,
                'Chen',
                'JCHEN',
                DATE '2005-09-28',
                'FI_ACCOUNT',
                2000,
                100 );
END;
/

-- Chen, details do not match, fail
BEGIN
    pack_employee.update_emp( 110,
                'XXXX',
                'JCHEN',
                DATE '2005-09-28',
                'FI_ACCOUNT',
                2000,
                100 );
END;
/

-- Johnston, dept does not exist, fail
BEGIN
    pack_employee.update_emp( 999,
                'Johnston',
                'JJ',
                DATE '2018-06-08',
                'IT_PROG',
                20000,
                999 );
END;
/

-- Johnston, department has no manager, fail
BEGIN
    pack_employee.update_emp( 999,
                'Johnston',
                'JJ',
                DATE '2018-06-08',
                'IT_PROG',
                20000,
                120 );
END;
/

-- Johnston, valid dept, insert new employee, success
BEGIN
    pack_employee.update_emp( 999,
                'Johnston',
                'JJ',
                DATE '2018-06-08',
                'IT_PROG',
                20000,
                100 );
END;
/

ROLLBACK;

DROP PACKAGE pack_employee;
