package com.fidelity.test.helper;

import java.io.IOException;
import java.sql.SQLException;

import org.dbunit.DatabaseUnitException;

import com.fidelity.integration.HighLowTempDao;

public class CreateDataSet {

	public static void main(String[] args) {

		HighLowTempDao dao = new HighLowTempDao();
		try {
			dao.makeDbUnitDataSet("data.xml");
		} catch (DatabaseUnitException | IOException | SQLException e) {
			e.printStackTrace();
		}
	}

}
