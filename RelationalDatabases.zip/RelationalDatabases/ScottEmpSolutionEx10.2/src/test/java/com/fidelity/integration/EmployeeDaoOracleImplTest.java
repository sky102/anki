package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Employee;

class EmployeeDaoOracleImplTest {
	EmployeeDao dao;
	
	Employee emp7369;
	Employee emp7934;
	Employee new8000;
	Employee new8001;
	
	@BeforeEach
	void setUp() {
		dao = new EmployeeDaoOracleImpl();
		
		// 10.1 #1 NULL commission handled correctly
		// Optional 10.1 #2 Leave manager handled by autoboxing
		// 10.2 #1 format of date no longer depends on query and/or database parameters
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, LocalDate.of(1980, 12, 17), new BigDecimal("800.00"), null, 20);
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, LocalDate.of(1982, 1, 23), new BigDecimal("1300.00"), null, 10);
		new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, LocalDate.of(1981, 1, 18), new BigDecimal("500.00"), 
				new BigDecimal("1.00"), 10);
		new8001 = new Employee(8001, "CARPENTER", "SALESMAN", 7499, LocalDate.of(1983, 2, 22), new BigDecimal("1700.00"),
				new BigDecimal("100.00"), 30);
	}

	// 7.4 #3
	@AfterEach
	void tearDown() {
		dao.close();
	}

	// 7.4 #4b Removed explicit test for connection

	// 7.2 #1
	@Test
	void testQueryAllEmployees() {
		List<Employee> emps = dao.queryAllEmployees();
		assertEquals(14, emps.size(), "Should be 14 records");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain MILLER 7934");
	}
	
	// 7.2 #2
	@Test
	void testQueryEmployeeByName() {
		List<Employee> emps = dao.queryEmployeesByName("SMITH");
		assertEquals(1, emps.size(), "Should be 1 record");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
	}

	@Test
	void testQueryEmployeeByNameFail() {
		List<Employee> emps = dao.queryEmployeesByName("PANKHURST");
		assertEquals(0, emps.size(), "Should be 0 records");
	}
	
	// 7.3 #1
	@Test
	void testQueryEmployeesByNameInjection() {
		List<Employee> emps = dao.queryEmployeesByName("SMITH' OR '1' = '1");
		assertEquals(0, emps.size(), "Should be 0 records");
	}
	

	// Optional 7.2 #3
	@Test
	void testQueryEmployeeByNumber7369() {
		Employee emp = dao.queryEmployeeByNumber(7369);
		assertEquals(emp7369, emp);
	}
	
	@Test
	void testQueryEmployeeByNumber8000() {
		Employee emp = dao.queryEmployeeByNumber(8000);
		assertNull(emp);
	}
	
	// Optional 7.2 #4
	@Test
	void testQueryEmployeesByDept10() {
		List<Employee> emps = dao.queryEmployeesByDepartment(10);
		assertEquals(3, emps.size(), "Should be 3 records");
		assertFalse(emps.contains(emp7369), "Should not contain SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain MILLER 7934");
	}
	
	@Test
	void testQueryEmployeesByDept20() {
		List<Employee> emps = dao.queryEmployeesByDepartment(20);
		assertEquals(5, emps.size(), "Should be 5 records");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
		assertFalse(emps.contains(emp7934), "Should not contain MILLER 7934");
	}

	@Test
	void testQueryEmployeesByDept90() {
		List<Employee> emps = dao.queryEmployeesByDepartment(90);
		assertEquals(0, emps.size(), "Should be 0 records");
	}

	// 9.1 #1
	@Test
	void testUpdateEmployee() {
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, LocalDate.of(1981, 1, 18), new BigDecimal("500.00"), 
				new BigDecimal("1.00"), 10);
		List<Employee> emps = dao.queryAllEmployees();
		assertFalse(emps.contains(upd7369), "Should not contain new values before update");
		dao.updateEmployee(upd7369);
		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(upd7369), "Should contain new values after update");
		dao.updateEmployee(emp7369);
		emps = dao.queryAllEmployees();
		assertFalse(emps.contains(upd7369), "Should not contain new values after reset");
		assertTrue(emps.contains(emp7369), "Should contain old values after reset");
	}

	// 9.1 #2
	@Test
	void testInsertEmployee() {
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, LocalDate.of(1981, 1, 18), new BigDecimal("500.00"), 
				new BigDecimal("1.00"), 10);
		List<Employee> emps = dao.queryAllEmployees();
		int oldSize = emps.size();
		assertFalse(emps.contains(new8000), "Should not contain new values before insert");
		dao.insertEmployee(new8000);
		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(new8000), "Should contain new values after insert");
		assertEquals(oldSize + 1, emps.size(), "Should have one more employee after insert");
		dao.deleteEmployee(8000);
		emps = dao.queryAllEmployees();
		assertFalse(emps.contains(new8000), "Should not contain new values after delete");
		assertEquals(oldSize, emps.size(), "Should have same number of employees as at start after delete");
	}

	@Test
	void testInsertDuplicateEmployee() {
		Exception e = assertThrows(DatabaseException.class, () -> {
			dao.insertEmployee(emp7369);
		});
		assertEquals("Cannot insert employee", e.getMessage());
		/*
		 *  We could do more processing here.
		 * 
		 *  For example, the underlying exception type is SQLIntegrityConstraintViolationException, but for our
		 *  purposes, we will just check the message.
		 */
		Throwable cause = e.getCause();
		assertEquals("ORA-00001: unique constraint (SCOTT.PK_EMP) violated\n", cause.getMessage());
	}
	
	// Optional 9.1 #3: update salary for employees hired before a certain date
	// 10.1 #1: updated raise to BigDecimal
	@Test
	void testUpdateEmployeeSalary() {
		Employee upd7369 = new Employee(7369, "SMITH", "CLERK", 7902, LocalDate.of(1980, 12, 17), new BigDecimal("1000.00"), 
				null, 20);
		Employee upd7499 = new Employee(7499, "ALLEN", "SALESMAN", 7698, LocalDate.of(1981, 2, 20), new BigDecimal("1800.00"), 
				new BigDecimal("300.00"), 30);
		Employee emp7499 = new Employee(7499, "ALLEN", "SALESMAN", 7698, LocalDate.of(1981, 2, 20), new BigDecimal("1600.00"), 
				new BigDecimal("300.00"), 30);
		// condition is less than, not less than and equal, so this value is on the border and should not be changed
		Employee emp7521 = new Employee(7521, "WARD", "SALESMAN", 7698, LocalDate.of(1981, 2, 22), new BigDecimal("1250.00"), 
				new BigDecimal("500.00"), 30);

		List<Employee> emps = dao.queryAllEmployees();
		// already have a check for 7369 elsewhere
		// keep our tests simpler by assuming primary key constraint works
		assertTrue(emps.contains(emp7499), "Should contain old values before update ALLEN 7499");
		assertTrue(emps.contains(emp7521), "Should contain unchanged values before update WARD 7521");

		int rows = dao.updateEmployeeSalary(new BigDecimal("200.0"), LocalDate.of(1981, 2, 22));
		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(upd7369), "Should contain new values after update SMITH 7369");
		assertTrue(emps.contains(upd7499), "Should contain new values after update ALLEN 7499");
		assertTrue(emps.contains(emp7521), "Should contain unchanged values after update WARD 7521");
		assertEquals(2, rows, "Should be 2 rows affected");
		
		// Reset data
		rows = dao.updateEmployeeSalary(new BigDecimal("-200.0"), LocalDate.of(1981, 2, 22));
		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(emp7369), "Should contain old values after reset SMITH 7369");
		assertTrue(emps.contains(emp7499), "Should contain old values after reset ALLEN 7499");
		assertTrue(emps.contains(emp7521), "Should contain unchanged values after reset WARD 7521");
		assertEquals(2, rows, "Should be 2 rows affected");
	}
	
	// Optional 9.1 #4: batch update of employees
	@Test
	void testUpdateEmployees() {
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, LocalDate.of(1981, 1, 18), new BigDecimal("500.00"), 
				new BigDecimal("1.00"), 10);
		Employee upd7934 = new Employee(7934, "CARPENTER", "SALESMAN", 7499, LocalDate.of(1983, 2, 22), new BigDecimal("1700.0"),
				new BigDecimal("100.00"), 30);

		List<Employee> updates = new ArrayList<>();
		updates.add(upd7369);
		updates.add(upd7934);
		dao.updateEmployee(updates);

		List<Employee> emps = dao.queryAllEmployees();
		assertTrue(emps.contains(upd7369), "Should contain new values after update HEYES 7369");
		assertTrue(emps.contains(upd7934), "Should contain new values after update CARPENTER 7934");
		
		// Reset data
		updates.clear();
		updates.add(emp7369);
		updates.add(emp7934);
		dao.updateEmployee(updates);

		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(emp7369), "Should contain old values after reset SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain old values after reset MILLER 7934");
	}
	
	// Optional 9.1 #4: batch insert of employees
	@Test
	void testInsertEmployees() {
		List<Employee> emps = dao.queryAllEmployees();
		int oldSize = emps.size();
		assertFalse(emps.contains(new8000), "Should not contain new values before update HEYES 8000");
		assertFalse(emps.contains(new8001), "Should not contain new values before update CARPENTER 8001");

		List<Employee> inserts = new ArrayList<>();
		inserts.add(new8000);
		inserts.add(new8001);
		dao.insertEmployee(inserts);

		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(new8000), "Should contain new values after update HEYES 8000");
		assertTrue(emps.contains(new8001), "Should contain new values after update CARPENTER 8001");
		assertEquals(oldSize + 2, emps.size(), "Size should have increased by 2 after insert");
		
		// Reset data
		List<Integer> deletes = new ArrayList<>();
		deletes.add(8000);
		deletes.add(8001);
		dao.deleteEmployee(deletes);
		emps = dao.queryAllEmployees();
		assertFalse(emps.contains(new8000), "Should not contain new values after reset HEYES 8000");
		assertFalse(emps.contains(new8001), "Should not contain new values after reset CARPENTER 8001");
		assertEquals(oldSize, emps.size(), "Size should have returned to pre-insert size");
	}
	
	// 9.2 #1: transactional insert of employees
	@Test
	void testInsertEmployeeInTransaction() {
		List<Employee> emps = dao.queryAllEmployees();
		int oldSize = emps.size();

		List<Employee> inserts = new ArrayList<>();
		inserts.add(new8000);
		inserts.add(new8001);
		dao.insertEmployeeInTransaction(inserts);

		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(new8000), "Should contain new values after update HEYES 8000");
		assertTrue(emps.contains(new8001), "Should contain new values after update CARPENTER 8001");
		assertEquals(oldSize + 2, emps.size(), "Size should have increased by 2 after insert");

		// Reset data
		List<Integer> deletes = new ArrayList<>();
		deletes.add(8000);
		deletes.add(8001);
		dao.deleteEmployee(deletes);
		emps = dao.queryAllEmployees();
		assertFalse(emps.contains(new8000), "Should not contain new values after reset HEYES 8000");
		assertFalse(emps.contains(new8001), "Should not contain new values after reset CARPENTER 8001");
		assertEquals(oldSize, emps.size(), "Size should have returned to pre-insert size");
	}
	
	@Test
	void testInsertEmployeeInTransactionFail() {
		List<Employee> emps = dao.queryAllEmployees();
		int oldSize = emps.size();

		assertThrows(DatabaseException.class, () -> {
			List<Employee> inserts = new ArrayList<>();
			inserts.add(new8000);
			inserts.add(emp7369);
			dao.insertEmployeeInTransaction(inserts);
		});

		emps = dao.queryAllEmployees();
		assertFalse(emps.contains(new8000), "Should not contain new values after failed update");
		assertEquals(oldSize, emps.size(), "Size should have stayed the same");
	}

	// Optional 10.1 #2
	@Test
	void testNullManager() {
		Employee new8002 = new Employee(8002, "IMPERATOR", "PRESIDENT", null, LocalDate.of(1980, 11, 17), new BigDecimal("6000.0"), 
				new BigDecimal("1.0"), 10);
		dao.insertEmployee(new8002);
		assertEquals(new8002, dao.queryEmployeeByNumber(8002));
		
		// Reset data
		dao.deleteEmployee(8002);
		assertNull(dao.queryEmployeeByNumber(8002));
	}

	// 10.2 #1
	@Test
	void testUpdateEmployeeSalaryNullDate() {
		assertThrows(NullPointerException.class, () -> {
			dao.updateEmployeeSalary(new BigDecimal("200.0"), null);
		});
	}
}
