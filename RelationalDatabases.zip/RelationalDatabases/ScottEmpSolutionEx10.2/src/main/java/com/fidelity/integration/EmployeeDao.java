package com.fidelity.integration;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import com.fidelity.model.Employee;

public interface EmployeeDao {

	// 7.4 #3
	void close();

	// 7.2 #1
	List<Employee> queryAllEmployees();

	// 7.2 #2
	// 7.3 #1
	List<Employee> queryEmployeesByName(String name);

	// Optional 7.2 #3
	// Optional 7.3 #3
	Employee queryEmployeeByNumber(int empNo);

	// Optional 7.2 #4
	// Optional 7.3 #4
	List<Employee> queryEmployeesByDepartment(int deptNo);

	// 9.1 #1
	void updateEmployee(Employee upd7369);

	// 9.1 #2
	void insertEmployee(Employee new8000);
	void deleteEmployee(int i);

	// Optional 9.1 #3
	// 10.1 #1 updated to BigDecimal
	// 10.2 #1 updated to LocalDate (could have converted, but better to change)
	int updateEmployeeSalary(BigDecimal raise, LocalDate date);

	// Optional 9.1 #4
	void updateEmployee(List<Employee> emps);
	void insertEmployee(List<Employee> emps);
	void deleteEmployee(List<Integer> emps);

	// 9.2 #1
	void insertEmployeeInTransaction(List<Employee> emps);

}
