package com.fidelity.domain;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;

import org.bson.BsonReader;
import org.bson.BsonWriter;
import org.bson.Document;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.junit.jupiter.api.Test;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

/*
 * This class illustrates access to the stocks collection.
 * 
 * It also illustrates how to access the database without a DAO.
 */
public class StockMongoTest {

	@Test
	void testGetCollection() {
		try(MongoClient mongoClient = new MongoClient("localhost", 27017)) {
			MongoDatabase db = mongoClient.getDatabase("stockdb");
			MongoCollection<Document> stocks = db.getCollection("stocks");

			FindIterable<Document> iter = stocks.find();
			for (Document stock : iter) {
				System.out.println(stock);
				assertNotNull(stock);
			}
		}
	}

	@Test
	void testGetCollectionTyped() {
		/*
		 * This is configured so the BigDecimalCodec defined below is used for ALL BigDecimal
		 * values. If that isn't what is required, we can define a more specific codec for
		 * the Stock class using CodecProvider and BsonTypeClassMap or by using a ClassModel
		 * with PojoCodecProvider: http://mongodb.github.io/mongo-java-driver/3.9/bson/
		 * 
		 * Compare the CodeRegistry declaration with the one in ProductMongoDao.
		 */
		CodecRegistry pojoCodecRegistry = CodecRegistries.fromRegistries(
				CodecRegistries.fromCodecs(new BigDecimalCodec()),
				MongoClient.getDefaultCodecRegistry(),
				CodecRegistries.fromProviders(PojoCodecProvider.builder().automatic(true).build()));
		MongoClientOptions options = MongoClientOptions.builder()
				.codecRegistry(pojoCodecRegistry)
				.build();
		MongoClient mongoClient = new MongoClient("localhost", options);

		MongoDatabase db = mongoClient.getDatabase("stockdb");
		MongoCollection<Stock> stocks = db.getCollection("stocks", Stock.class);

		FindIterable<Stock> iter = stocks.find();
		for (Stock stock : iter) {
			System.out.println(stock);
			assertNotNull(stock);
		}
		
		mongoClient.close();
	}

	/*
	 * This illustrates how to convert between MongoDB double to Java BigDecimal.
	 * 
	 * The exercise creates the stocks collection with double, whereas the Stock class
	 * uses BigDecimal. Since MongoDB 3.4, it would probably be better to create the
	 * collection with BSON DECIMAL128 as the numeric type since that will automatically
	 * be converted to BigDecimal.
	 * 
	 * To do that, replace this command:
	 *   stock = {exchange: "NYSE", symbol: "IBM", price: 150.00}
	 * with this:
	 *   stock = {exchange: "NYSE", symbol: "IBM", price: NumberDecimal("150.00")}
	 *   
	 * But, since we didn't do that, we need to do a conversion. This codec will
	 * convert any BigDecimal value to double for writing and vice versa for reading.
	 */
	public static class BigDecimalCodec implements Codec<BigDecimal> {
	    @Override
	    public void encode(final BsonWriter writer, final BigDecimal value, final EncoderContext encoderContext) {
	        writer.writeDouble(value.doubleValue());
	    }

	    @Override
	    public BigDecimal decode(final BsonReader reader, final DecoderContext decoderContext) {
	        return new BigDecimal(reader.readDouble());
	    }

	    @Override
	    public Class<BigDecimal> getEncoderClass() {
	        return BigDecimal.class;
	    }
	}
}
