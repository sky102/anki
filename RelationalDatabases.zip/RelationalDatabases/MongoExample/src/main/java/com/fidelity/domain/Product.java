package com.fidelity.domain;

import org.bson.types.ObjectId;

public class Product {

	private ObjectId id;
	private String item;
	private String manufacturer;
	private double price;
	
	public Product() {
	}

	public ObjectId getId() {
		return id;
	}

	public Product(String item, String manufacturer, double price) {
		super();
		this.item = item;
		this.manufacturer = manufacturer;
		this.price = price;
	}

	public void setId(ObjectId id) {
		this.id = id;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", item=" + item + ", manufacturer=" + manufacturer + ", price=" + price + "]";
	}

}
