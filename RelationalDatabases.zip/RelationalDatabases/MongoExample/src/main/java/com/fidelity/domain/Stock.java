package com.fidelity.domain;

import java.math.BigDecimal;

public class Stock {

	String exchange;
	String symbol;
	BigDecimal price;

	public Stock() {
	}

	public String getExchange() {
		return exchange;
	}

	public void setExchange(String exchange) {
		this.exchange = exchange;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Stock [exchange=" + exchange + ", symbol=" + symbol + ", price=" + price + "]";
	}

}
