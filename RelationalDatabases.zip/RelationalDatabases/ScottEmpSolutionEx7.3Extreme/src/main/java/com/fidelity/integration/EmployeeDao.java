package com.fidelity.integration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.Employee;

/*
 * This represents a more extreme re-factoring of the queries. Details are below.
 * 
 * Subsequent solutions do NOT build on this re-factoring.
 */
public class EmployeeDao {
    private final Logger logger = LoggerFactory.getLogger(EmployeeDao.class);
	
	private Connection conn;

	public Connection getConnection() throws SQLException {

		if (conn == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");

				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				/*
				 * Why throw SQLException, but catch IOException?
				 * 
				 * Because all the exception handling is a compromise at this point. There is a much better solution
				 * that we will discover later. So many JDBC methods throw SQLException that we will need handling 
				 * for that in every other method of the DAO, whereas only this method throws IOException.
				 */
				logger.error("Cannot read db.properties", e);
			}
		}
		return conn;
	}

	// 7.2 #1
	// Optional 7.3 #2: heavily re-factored
	public List<Employee> queryAllEmployees() {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp";
		return queryEmployees(sql, new Consumer<PreparedStatement>() {
			@Override
			public void accept(PreparedStatement stmt) {
				// do nothing
			}
		});
	}

	/*
	 * Optional 7.3 #2: this is a fairly heavy re-factoring!
	 * 
	 * You should have realized by now that there are only two things that are different in different queries for the
	 * same object: 1. the query string and 2. the parameters.
	 * 
	 * This method accepts two inputs:
	 * 1. a query string
	 * 2. a callback method that will be used to set the parameters
	 * 
	 * The callback method is an instance of the Consumer interface, which is an interface that accepts a single parameter
	 * and returns no values. We use this rather than declare our own interface with a single method, but of course we could
	 * have done that quite easily. Using the existing interface, specifically designed for this sort of situation, avoids
	 * polluting our code with another interface.
	 * 
	 * We could equally have had the method accept a list of parameters. While that is slightly easier to use, the actual
	 * code to process that list correctly is rather complicated.
	 */
	private List<Employee> queryEmployees(String sql, Consumer<PreparedStatement> callback) {
		List<Employee> emps = new ArrayList<>();
		// Declare these outside the try-catch-finally block so they are available in finally
		PreparedStatement stmt = null;
		Connection conn = null;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			callback.accept(stmt);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int empNumber = rs.getInt("empno");
				String empName = rs.getString("ename");
				String job = rs.getString("job");
				int mgrNumber = rs.getInt("mgr");
				String hireDate = rs.getString("hiredate");
				double sal = rs.getDouble("sal");
				double comm = rs.getDouble("comm");
				int deptNumber = rs.getInt("deptno");
				Employee emp = new Employee(empNumber, empName, job, mgrNumber, hireDate, sal, comm, deptNumber);
				emps.add(emp);
			}
		} catch (SQLException e) {
			// This logs the error, but effectively ignores it. Better solution coming soon.
			logger.error("Cannot execute queryEmployees: {}", sql, e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close statement", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close connection", e);
				}
			}
		}
		return emps;
	}

	// 7.2 #2
	// Optional 7.3 #2: heavily re-factored
	public List<Employee> queryEmployeesByName(String name) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp"
				+ " WHERE ename = ?";
		return queryEmployees(sql, new Consumer<PreparedStatement>() {
			@Override
			public void accept(PreparedStatement stmt) {
				try {
					stmt.setString(1, name);
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot set name in query: {}", name, e);
				}
			}
		});
	}

	// Optional 7.2 #3
	// Optional 7.3 #3: heavily re-factored
	public Employee queryEmployeeByNumber(int empNo) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE empno = ?";
		List<Employee> emps = queryEmployees(sql, new Consumer<PreparedStatement>() {
			@Override
			public void accept(PreparedStatement stmt) {
				try {
					stmt.setInt(1, empNo);
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot set employee number in query: {}", empNo, e);
				}
			}
		});
		/*
		 * This method only returns one Employee, but the generic query handler (queryEmployees) returns a list.
		 * 
		 * Return the first item in the list, if there is one. Doing it this way avoids an index out of bounds exception.
		 */
		return emps.size() > 0 ? emps.get(0) : null;
	}

	// Optional 7.2 #4
	// Optional 7.3 #4: heavily re-factored
	public List<Employee> queryEmployeesByDepartment(int deptNo) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE deptno = ?";
		return queryEmployees(sql, new Consumer<PreparedStatement>() {
			@Override
			public void accept(PreparedStatement stmt) {
				try {
					stmt.setInt(1, deptNo);
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot set department number in query: {}", deptNo, e);
				}
			}
		});
	}

}
