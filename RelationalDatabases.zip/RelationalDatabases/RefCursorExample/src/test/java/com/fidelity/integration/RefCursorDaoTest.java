package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Employee;

class RefCursorDaoTest {

	private RefCursorDao dao;
	
	@BeforeEach
	void setUp() {
		dao = new RefCursorDao();
	}
	
	@AfterEach
	void tearDown() {
		dao.close();
	}
	
	@Test
	void testQueryByDept() {
		Employee expected = new Employee(7782, "CLARK", "MANAGER", 7839, LocalDate.of(1981, 6, 9), 2450, 0, 10);
		List<Employee> emps = dao.queryEmployeesByDepartment(10);
		assertNotNull(emps, "Should return valid list of depts");
		assertTrue(emps.contains(expected), "Should contain CLARK");
		assertEquals(3, emps.size(), "Should be 3 records");
		
		System.out.println(emps);
	}

}
