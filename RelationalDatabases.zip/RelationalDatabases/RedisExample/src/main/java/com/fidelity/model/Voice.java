package com.fidelity.model;

public enum Voice {
	DRAMATIC_TENOR, TENOR
}
