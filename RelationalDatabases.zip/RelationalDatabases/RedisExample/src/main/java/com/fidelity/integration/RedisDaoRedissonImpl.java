package com.fidelity.integration;

import org.redisson.Redisson;
import org.redisson.api.RBucket;
import org.redisson.api.RKeys;
import org.redisson.api.RedissonClient;
import org.redisson.codec.JsonJacksonCodec;
import org.redisson.config.Config;

import com.fidelity.model.Character;

public class RedisDaoRedissonImpl implements RedisDao {
	private RedissonClient redisson;

	public RedisDaoRedissonImpl() {
		Config config = new Config();
		/*
		 * In this case we will use the Jackson JSON codec. The default codec is
		 * FST, which requires the class to be serializable.
		 * 
		 * However, when setting any parameters, we need to set the server.
		 * Otherwise we could use the version of create() that takes no parameter.
		 */
		config.useSingleServer().setAddress("redis://127.0.0.1:6379");
		config.setCodec(new JsonJacksonCodec());
		redisson = Redisson.create(config);
	}

	@Override
	public void deleteAllKeys() {
		RKeys keys = redisson.getKeys();
		keys.flushdb();
	}

	/*
	 * Treat String as object. But there are specific types for AtomicLong
	 * and AtomicDouble.
	 */
	@Override
	public void setUserName(int clientId, String name) {
		String key = "simple:character:" + Integer.toString(clientId) + ":name";
		RBucket<String> bucket = redisson.getBucket(key);
		bucket.set(name);
	}

	@Override
	public String getUserName(int clientId) {
		String key = "simple:character:" + Integer.toString(clientId) + ":name";
		RBucket<String> bucket = redisson.getBucket(key);
		return bucket.get();
	}

	@Override
	public void storeCharacter(String key, Character character) {
		key = "object:character:" + key;
		RBucket<Character> bucket = redisson.getBucket(key);
		bucket.set(character);
	}

	@Override
	public Character getCharacter(String key) {
		key = "object:character:" + key;
		RBucket<Character> bucket = redisson.getBucket(key);
		return bucket.get();
	}

}
