package com.fidelity.integration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fidelity.model.Character;
import com.fidelity.model.Voice;

import redis.clients.jedis.Jedis;

public class RedisDaoJedisImpl implements RedisDao {
	private Jedis jedis;
	
	public RedisDaoJedisImpl() {
		// To work with default port on localhost, we don't need any parameters
		jedis = new Jedis();
	}
	
	@Override
	public void deleteAllKeys() {
		jedis.flushDB();
	}

	/*
	 * Choose one key scheme and stick to it (e.g. type:id:attribute, or
	 * type/id/attribute).
	 * 
	 * All Redis types can support full binary data.
	 */
	@Override
	public void setUserName(int clientId, String name) {
		String key = "simple:character:" + Integer.toString(clientId) + ":name";
		jedis.set(key, name);
	}

	@Override
	public String getUserName(int clientId) {
		String key = "simple:character:" + Integer.toString(clientId) + ":name";
		return jedis.get(key);
	}

	/*
	 * A Redis hash is a natural data type to store object data, but doesn't have 
	 * any specific support for object packaging, so objects need to be packaged
	 * and unpackaged manually.
	 * 
	 * Object can also be serialized to a known format and stored in a simple key.
	 * Typical formats are JSON (via, say, Jackson or Fastjson), Java serialization 
	 * or binary JSON (e.g. by kryo). However, doing this prevents working directly
	 * on the data using Redis primitives (e.g. transactional increment).
	 */
	@Override
	public void storeCharacter(String key, Character character) {
		key = "hash:character:" + key;
		jedis.hmset(key, convertCharacterToHash(character));
	}
	
	private Map<String, String> convertCharacterToHash(Character character) {
		Map<String, String> hash = new HashMap<>();
		hash.put("firstName", character.getFirstName());
		hash.put("lastName", character.getLastName());
		hash.put("voice", character.getVoice().toString());
		return hash;
	}

	@Override
	public Character getCharacter(String key) {
		key = "hash:character:" + key;
		List<String> values = jedis.hmget(key, "firstName", "lastName", "voice");
		return convertListToCharacter(values);
	}

	private Character convertListToCharacter(List<String> values) {
		String firstName = values.get(0);
		String lastName = values.get(1);
		Voice voice = Voice.valueOf(values.get(2));
		return new Character(firstName, lastName, voice);
	}

}
