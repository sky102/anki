package com.fidelity.dynamodb;

import java.util.List;

import com.fidelity.model.Music;

public interface DynamoDbDao {

	void deleteTable(boolean ignoreNotFound);

	void createTable();

	boolean checkTableExists();

	void putItem(Music music);

	void putItemExtended(Music music);

	Music getMusicByKey(String artist, String trackTitle);

	List<Music> getAllMusic();

	List<Music> getThreeMinuteTracks();

	List<Music> queryMusicByArtist(String artist);

}