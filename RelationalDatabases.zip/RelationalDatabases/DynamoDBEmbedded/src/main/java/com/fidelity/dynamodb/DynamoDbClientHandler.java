package com.fidelity.dynamodb;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.fidelity.properties.PropertyUtils;

/*
 * Class to extract common functionality for creating a low level DynamoDB
 * client (AmazonDynamoDB).
 * 
 * If running with the embedded DynamoDBLocal, then we never get here because
 * there is no endpoint and the client was passed into the DAO as a parameter.
 * 
 * If running with standalone DynamoDBLocal, the url and region must be
 * specified.
 * 
 * If running with remote DynamoDB, the endpoint is set by the region. We can
 * either use defaultclient(), which reads everything from the aws configuration,
 * or set the region using the standard client and withRegion().
 */
public class DynamoDbClientHandler {
	public static AmazonDynamoDB getLowLevelClient() {
		String url = PropertyUtils.getUrl();
		String region = PropertyUtils.getRegion();

		if (url == null || url.isEmpty()) {
//				return AmazonDynamoDBClientBuilder.defaultClient();
			return AmazonDynamoDBClientBuilder.standard()
					.withRegion(region)
					.build();
		} else {
			return AmazonDynamoDBClientBuilder.standard()
					.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(url, region))
					.build();
		}
	}

}
