package com.fidelity.dynamodb;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.local.embedded.DynamoDBEmbedded;
import com.amazonaws.services.dynamodbv2.local.main.ServerRunner;
import com.amazonaws.services.dynamodbv2.local.server.DynamoDBProxyServer;
import com.fidelity.model.Music;
import com.fidelity.properties.PropertyUtils;

class DynamoDbDocumentDaoTest {
	DynamoDbDao dao;

	static DynamoDBProxyServer server;
	static AmazonDynamoDB add;

	/*
	 * Normally we would make this choice up-front and only have one way of running
	 * DynamoDB, but for illustration purposes, these tests will work with either
	 * an embedded version or a local version.
	 * 
	 * If the dyn.embedded property is set to true, then the tests will run with an 
	 * embedded version of DynamoDB. This runs "in process", so there is no endpoint
	 * to connect to. For that reason, we have to pass the AmazonDynamoDB instance
	 * into the DAO. This is far from ideal.
	 * 
	 * If the dyn.embedded property is set to anything other than true, or not set, 
	 * then the tests will run with DynamoDBLocal. This version runs "in memory", so
	 * nothing is persisted to disk, but it does run over http, so there is an endpoint
	 * just as there would be with remote DynamoDB. However, if running locally, the
	 * endpoint cannot be automatically configured and the connection mechanism is,
	 * therefore, different: this is also far from ideal.
	 */
	@BeforeAll
	static void setUpClass() throws Exception {
		/*
		 * This is far from ideal, but DynamoDBLocal depends on sqlite and must be told
		 * where the native libraries (dll, so) are. The pom ensures they are in a known
		 * location.
		 */
		System.setProperty("sqlite4java.library.path", "native-libs");
		if (PropertyUtils.getEmbedded()) {
			add = DynamoDBEmbedded.create().amazonDynamoDB();
		} else {
			String port = PropertyUtils.getPort();
			server = ServerRunner.createServerFromCommandLineArgs(new String[] { "-inMemory", "-port", port });
			server.start();
		}
	}

	@AfterAll
	static void tearDownClass() throws Exception {
		if (add != null) {
			add.shutdown();
		}
		if (server != null) {
			server.stop();
		}
	}
	
	@BeforeEach
	void setUp() {
		// If add is null, the DAO will ignore it
		dao = new DynamoDbDocumentDao(add);
		dao.deleteTable(true);
		dao.createTable();
	}

	@Test
	void testCreateTable() throws InterruptedException {
		assertTrue(dao.checkTableExists());
	}

	@Test
	void testInsertData() throws Exception {
		List<Music> music = normalInsertForTests();
		Music track = dao.getMusicByKey(music.get(0).getArtist(), music.get(0).getTrackTitle());
		assertEquals(music.get(0), track);
	}

	/*
	 * In this test we do not insert the data using the "normal" mechanism, which uses
	 * putItem, but just load the JSON file and then insert using putItemBySpec.
	 */
	@Test
	void testInsertDataBySpec() throws Exception {
		JsonTestUtils utils = new JsonTestUtils();
		List<Music> music = utils.loadData("music.json");
		for (Music track : music) {
			dao.putItemExtended(track);
			/*
			 * As with the CLI, the putItem does an insert if the item does not exist and
			 * an update if it does. The response (in this case a PutItemOutcome) will contain
			 * metadata (if requested) in all cases. In this case, we request the consumed
			 * capacity. It will only contain Item data if the item already existed and was
			 * replaced, so the first call to putItemBySpec will only return metadata and
			 * the second will return metadata and Item data.
			 */
			dao.putItemExtended(track);
		}
		List<Music> results = dao.getAllMusic();
		assertEquals(3, results.size());
		assertTrue(results.contains(music.get(0)));
	}

	@Test
	void testScan() throws Exception {
		List<Music> music = normalInsertForTests();
		List<Music> results = dao.getThreeMinuteTracks();
		assertEquals(1, results.size());
		assertTrue(results.contains(music.get(1)));
	}

	@Test
	void testQuery() throws Exception {
		List<Music> music = normalInsertForTests();
		List<Music> results = dao.queryMusicByArtist(music.get(0).getArtist());
		assertEquals(2, results.size());
		assertTrue(results.contains(music.get(0)));
		assertTrue(results.contains(music.get(1)));
	}

	private List<Music> normalInsertForTests() throws Exception {
		JsonTestUtils utils = new JsonTestUtils();
		List<Music> music = utils.loadData("music.json");
		for (Music track : music) {
			dao.putItem(track);
		}
		// Guard assertion to check that file was mapped correctly
		assertTrue(music.contains(new Music("Marisa Monte", "Amor I Love You", 
				"Memorias, Cronicas e Declaracoes de Amor", 2000, 191, 
				Arrays.asList("MPB", "Pop Rock"), true)));
		return music;
	}

}
