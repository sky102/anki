package com.fidelity.integration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class EmployeeDao {
	
	private Connection conn;

	public Connection getConnection() throws SQLException, IOException {

		if (conn == null) {
			Properties properties = new Properties();
			properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
			String dbUrl = properties.getProperty("db.url");
			String user = properties.getProperty("db.username");
			String password = properties.getProperty("db.password");

			conn = DriverManager.getConnection(dbUrl, user, password);
		}
		return conn;
	}



}
