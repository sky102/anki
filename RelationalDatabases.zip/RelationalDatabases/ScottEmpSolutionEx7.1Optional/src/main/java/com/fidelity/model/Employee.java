package com.fidelity.model;

public class Employee {
	private int empNumber;
	private String empName;
	private String job;
	private int mgrNumber;
	private String hireDate;
	private double salary;
	private double comm;
	private int deptNumber;
	
}
