package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EmployeeDaoTest {
	EmployeeDao dao;
	
	@BeforeEach
	void setUp() {
		dao = new EmployeeDao();
	}

	@Test
	void testConnection() throws SQLException, IOException {
		Connection conn = dao.getConnection();
		assertNotNull(conn);
	}

}
