package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Employee;

/*
 * 10.3
 * 
 * These tests contain embedded transactions, so they must be tested separately
 */
class EmployeeDaoOracleImplNonTransTest {
	EmployeeDao dao;
	
	Employee emp7369;
	Employee new8000;
	Employee new8001;
	
	@BeforeEach
	void setUp() {
		dao = new EmployeeDaoOracleImpl();
		
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, LocalDate.of(1980, 12, 17), new BigDecimal("800.00"), null, 20);
		new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, LocalDate.of(1981, 1, 18), new BigDecimal("500.00"), 
				new BigDecimal("1.00"), 10);
		new8001 = new Employee(8001, "CARPENTER", "SALESMAN", 7499, LocalDate.of(1983, 2, 22), new BigDecimal("1700.00"),
				new BigDecimal("100.00"), 30);
	}

	// 7.4 #3
	@AfterEach
	void tearDown() {
		dao.close();
	}
	
	// 9.2 #1: transactional insert of employees
	@Test
	void testInsertEmployeeInTransaction() {
		List<Employee> emps = dao.queryAllEmployees();
		int oldSize = emps.size();

		List<Employee> inserts = new ArrayList<>();
		inserts.add(new8000);
		inserts.add(new8001);
		dao.insertEmployeeInTransaction(inserts);

		emps = dao.queryAllEmployees();
		assertTrue(emps.contains(new8000), "Should contain new values after update HEYES 8000");
		assertTrue(emps.contains(new8001), "Should contain new values after update CARPENTER 8001");
		assertEquals(oldSize + 2, emps.size(), "Size should have increased by 2 after insert");

		// Reset data
		List<Integer> deletes = new ArrayList<>();
		deletes.add(8000);
		deletes.add(8001);
		dao.deleteEmployee(deletes);
		emps = dao.queryAllEmployees();
		assertFalse(emps.contains(new8000), "Should not contain new values after reset HEYES 8000");
		assertFalse(emps.contains(new8001), "Should not contain new values after reset CARPENTER 8001");
		assertEquals(oldSize, emps.size(), "Size should have returned to pre-insert size");
	}
	
	@Test
	void testInsertEmployeeInTransactionFail() {
		List<Employee> emps = dao.queryAllEmployees();
		int oldSize = emps.size();

		assertThrows(DatabaseException.class, () -> {
			List<Employee> inserts = new ArrayList<>();
			inserts.add(new8000);
			inserts.add(emp7369);
			dao.insertEmployeeInTransaction(inserts);
		});

		emps = dao.queryAllEmployees();
		assertFalse(emps.contains(new8000), "Should not contain new values after failed update");
		assertEquals(oldSize, emps.size(), "Size should have stayed the same");
	}

}
