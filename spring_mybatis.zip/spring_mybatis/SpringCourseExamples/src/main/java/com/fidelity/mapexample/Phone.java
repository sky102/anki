package com.fidelity.mapexample;

public class Phone {
	String type;
	String number;
	
	public Phone(String type, String number) {
		super();
		this.type = type;
		this.number = number;
	}
}
