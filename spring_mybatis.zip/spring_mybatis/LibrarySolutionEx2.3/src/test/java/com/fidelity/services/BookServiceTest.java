package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fidelity.business.Book;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("classpath:library-beans.xml")
class BookServiceTest {
	@Autowired
	BookService service;

	@Test
	void testCreateBookService() {
		assertNotNull(service);
	}

	@Test
	void testQueryAllBooks() {
		List<Book> books = service.queryAllBooks();
		assertNotNull(books);
		
		for (Book book : books) {
			assertNotNull(book);
			assertNotNull(book.getTitle());
		}
		assertTrue(books.contains(new Book("UML Distilled", "Martin Fowler", "", 3)));
	}

}
