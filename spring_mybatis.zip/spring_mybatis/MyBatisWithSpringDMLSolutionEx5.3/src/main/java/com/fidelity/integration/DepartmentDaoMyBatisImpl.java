package com.fidelity.integration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fidelity.business.Department;

@Repository("departmentsDao")
public class DepartmentDaoMyBatisImpl {

	@Autowired
	DepartmentMapper departmentMapper;

	public List<Department> getAllDepartments() {
		return departmentMapper.getAllDepartments();
	}

	public List<Department> getAllDepartmentsAndEmployees() {
		return departmentMapper.getAllDepartmentsAndEmployees();
	}

	public boolean insertDepartment(Department dept) {
		return departmentMapper.insertDepartment(dept) == 1;
	}

	public boolean updateDepartment(Department dept) {
		return departmentMapper.updateDepartment(dept) == 1;
	}

	// Not asked for, but allows us to illustrate the constraint violation
	public boolean deleteDepartment(int deptId) {
		return departmentMapper.deleteDepartment(deptId) == 1;
	}

	public void reassignEmployeesDeleteDepartment(int deptDelete, int deptAssign) {
	    Map<Object, Object> parameterMap = new HashMap<>(2);
	    parameterMap.put("deptDelete", deptDelete);
	    parameterMap.put("deptAssign", deptAssign);
	    departmentMapper.reassignEmployeesDeleteDepartment(parameterMap);
	}

}
