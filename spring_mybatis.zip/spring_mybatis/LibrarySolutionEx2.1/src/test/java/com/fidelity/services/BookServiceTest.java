package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fidelity.business.Book;

class BookServiceTest {

	BookService service;
	AbstractApplicationContext context;
	String configFile = "library-beans.xml";

	@BeforeEach
	void setUp() throws Exception {
		context = new ClassPathXmlApplicationContext(configFile);
		service = context.getBean("bookService", BookService.class);
	}
	
	@AfterEach
	void tearDown() {
		context.close();
	}

	@Test
	void testCreateBookService() {
		assertNotNull(service);
	}

	@Test
	void testQueryAllBooks() {
		List<Book> books = service.queryAllBooks();
		assertNotNull(books);
		
		for (Book book : books) {
			assertNotNull(book);
			assertNotNull(book.getTitle());
		}
		assertTrue(books.contains(new Book("UML Distilled", "Martin Fowler", "", 3)));
	}

}
