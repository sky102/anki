package com.fidelity.integration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fidelity.business.Department;

@Repository("departmentsDao")
public class DepartmentDaoMyBatisImpl {
	@Autowired
	DepartmentMapper mapper;

	public List<Department> getAllDepartments() {
		return mapper.getAllDepartments();
	}

	public List<Department> getAllDepartmentsAndEmployees() {
		return mapper.getAllDepartmentsAndEmployees();
	}
	

}
