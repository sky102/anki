package com.fidelity.lambda;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Book;
import com.fidelity.model.DummyBookList;
import com.fidelity.model.Library;

public class LibraryTest {
	Library lib;
	
	// Done: Review and complete TODOs in Library
	
	@BeforeEach
	public void setUp() throws Exception {
		lib = new Library(DummyBookList.createBooksList());
	}
	
	@Test
	public void testSortByCost() {
		List<Book> books = lib.sortByPrice();
		double expectedMin = 20.94;
		double expectedMax = 54.03;
		double actual = books.get(0).getPrice();
		assertEquals(expectedMin, actual, 0.001);
		actual = books.get(books.size()-1).getPrice();
		assertEquals(expectedMax, actual, 0.001);
	}

	// Done: Define a test for sort by Title
	@Test
	public void testSortByTitle() {
		List<Book> books = lib.sortByTitle();
		String expectedMin = "Clean Architecture";
		String expectedMax = "UML Distilled";
		String actual = books.get(0).getTitle();
		assertEquals(expectedMin, actual);
		actual = books.get(books.size()-1).getTitle();
		assertEquals(expectedMax, actual);
	}

}
