package com.fidelity.streams;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Book;
import com.fidelity.model.DummyBookList;
import com.fidelity.model.Library;

public class StreamsTest {
	List<Book> books;

	@BeforeEach
	public void setUp() throws Exception {
		Library lib = new Library(DummyBookList.createBooksList());
		books = lib.getBooks();
	}

	@Test
	// Done: write the test to find the count of all the books written by Robert Martin
	// use streams to do this
	public void testFindCountOfBooksByRobertMartin() {
		String author = "Robert Martin";
		long expected = 3;
		
		long actual = books.stream()
						 .filter(b -> author.equals(b.getAuthor()))
						 .count();
		
		assertEquals(expected, actual);
	}
	
	@Test
	// Done: write the test to find all the books less than $50
	// use streams to do this
	public void testFindBooksLessThanFiftyDollars() {
		List<Book> results = books.stream()
				.filter(b -> b.getPrice() < 50.0)
				.collect(Collectors.toList());
		assertNotNull(results);

		int expected = 6;
		int actual = results.size();
		assertEquals(expected, actual);
	}

	@Test
	// Done: write the test to find all the books by Martin Fowler
	// use streams to do this
	public void testFindBooksByMartinFowler() {
		String author = "Martin Fowler";
		List<Book> results = books.stream()
								  .filter(b -> author.equals(b.getAuthor()))
								  .collect(Collectors.toList());
		assertNotNull(results);

		int expected = 3;
		int actual = results.size();
		assertEquals(expected, actual);
	}
	
	// These steps are optional
	
	@Test
	// Done: Optional exercise: write the test to find the highest priced book
	// use streams to do this. You will need to investigate the use of Optional<>
	public void testFindHighestPricedBook() {
		Optional<Book> maxBook = books.stream()
									  .max(Comparator.comparing(Book::getPrice));
		assertEquals( 54.03, maxBook.get().getPrice(), 0.001);
	}
	
	@Test
	// Done: Optional exercise: write the test to find any book written by Robert Martin
	// use streams to do this. You will need to use Optional<> again.
	public void testFindAnyBookByRobertMartin() {
		String author = "Robert Martin";
		Optional<Book> anyBook = books.stream()
									  .filter(b -> author.equals(b.getAuthor()))
									  .findAny();
		assertEquals(author, anyBook.get().getAuthor());
	}
	
}
