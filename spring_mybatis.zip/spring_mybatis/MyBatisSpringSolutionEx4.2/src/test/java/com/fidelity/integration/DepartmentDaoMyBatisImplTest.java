package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fidelity.business.Department;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("classpath:beans.xml")
class DepartmentDaoMyBatisImplTest {
	// Done: Deleted temporary test

	@Autowired
	DepartmentDaoMyBatisImpl dao;

	@Test
	void testGetAllDepartments() {
		List<Department> departments = dao.getAllDepartments();
		
		assertNotNull(departments);
		
		assertEquals(4, departments.size());
		
		for (Department department : departments) {
			assertNotNull(department);
			assertNotNull(department.getName());
		}
		assertTrue(departments.contains(new Department(10, "ACCOUNTING", "NEW YORK")));
	}

}
