package com.fidelity.birthday;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.Map;

public class Driver {

	public static void main(String[] args) {
		Map<String, Birthday> birthdays = createBirthdays();
		
		for (String name : birthdays.keySet()) {
			System.out.println(name + " was born on " + birthdays.get(name));
		}
	}

	/*
	 * Here are some sample birthdays (ignore the uncertainty)
	 * 
	 * Alexander Hamilton - 11 Jan 1757 (or possibly 1755!) - Charlestown, Saint Kitts and Nevis
	 * Winston Churchill - 30 Nov 1874 - Blenheim Palace, Woodstock, United Kingdom
	 * Jawaharlal Nehru - 14 Nov 1889 - Allahabad, India
	 * Nelson Mandela - 18 July 1918 - Mvezo, South Africa
	 * Charlemagne - 2 Apr 742 (probably) - Aachen, Germany (possibly!)
	 */
	private static Map<String, Birthday> createBirthdays() {
		Map<String, Birthday> birthdays = new HashMap<>();
		
		birthdays.put("Alexander Hamilton", 
				new Birthday(LocalDate.of(1757, Month.JANUARY, 11), "Charlestown, Saint Kitts and Nevis"));
		birthdays.put("Winston Churchill", 
				new Birthday(LocalDate.of(1874, Month.NOVEMBER, 30), "Blenheim Palace, Woodstock, United Kingdom"));
		birthdays.put("Jawaharlal Nehru", 
				new Birthday(LocalDate.of(1889, Month.NOVEMBER, 14), "Allahabad, India"));
		birthdays.put("Nelson Mandela", 
				new Birthday(LocalDate.of(1918, Month.JULY, 18), "Mvezo, South Africa"));
		birthdays.put("Charlemagne", 
				new Birthday(LocalDate.of(742, Month.APRIL, 2), "Aachen, Germany"));

		return birthdays;
	}
}
