-- Schema definition for the museum exhibits in the Java Museum

-- Exhibits
create table exhibits (name varchar(45), permanent char(1), cost integer);
