-- Inserting data into the Java Museum database

-- Exhibits
insert into exhibits values ('OKeefe', '1', 0);
insert into exhibits values ('Remington', '1', 0);
insert into exhibits values ('Turnbull', '1', 0);
insert into exhibits values ('Monet', '0', 850);
insert into exhibits values ('Moore', '0', 900);
insert into exhibits values ('WangDynasty', '0', 1300);
insert into exhibits values ('Amenhotep', '0', 2450);
insert into exhibits values ('ElginMarbles', '0', 825);
insert into exhibits values ('TogoFolkArt', '0', 735);


-- Commit
commit;