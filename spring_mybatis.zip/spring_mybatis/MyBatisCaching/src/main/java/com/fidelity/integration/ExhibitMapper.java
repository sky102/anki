package com.fidelity.integration;

import java.util.List;

import com.fidelity.business.Exhibit;

public interface ExhibitMapper {
	List<Exhibit> getAllExhibits();
}
