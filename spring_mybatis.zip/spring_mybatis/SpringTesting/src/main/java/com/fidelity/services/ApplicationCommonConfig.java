package com.fidelity.services;

import org.springframework.context.annotation.Configuration;

/*
 * Dummy class just to illustrate that you can import
 */
@Configuration
public class ApplicationCommonConfig {

}
