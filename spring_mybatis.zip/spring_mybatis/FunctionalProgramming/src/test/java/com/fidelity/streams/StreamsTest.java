package com.fidelity.streams;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Book;
import com.fidelity.model.DummyBookList;
import com.fidelity.model.Library;

public class StreamsTest {
	List<Book> books;

	@BeforeEach
	public void setUp() throws Exception {
		Library lib = new Library(DummyBookList.createBooksList());
		books = lib.getBooks();
	}

	@Test
	// TODO: write the test to find the count of all the books written by Robert Martin
	// use streams to do this
	public void testFindCountOfBooksByRobertMartin() {
		fail("the find count of books by Robert Martin test is not defined");
	}
	
	@Test
	// TODO: write the test to find all the books less than $50
	// use streams to do this
	public void testFindBooksLessThanFiftyDollars() {
		fail("the find books less than $50 test is not defined");
	}

	@Test
	// TODO: write the test to find all the books by Martin Fowler
	// use streams to do this
	public void testFindBooksByMartinFowler() {
		fail("the find books by Martin Fowler test is not defined");
	}
	
	// These steps are optional
	
	@Test
	// TODO: Optional exercise: write the test to find the highest priced book
	// use streams to do this. You will need to investigate the use of Optional<>
	public void testFindHighestPricedBook() {
		fail("the highest priced book test is not defined");
	}
	
	@Test
	// TODO: Optional exercise: write the test to find any book written by Robert Martin
	// use streams to do this. You will need to use Optional<> again.
	public void testFindAnyBookByRobertMartin() {
		fail("the find any book by Robert Martin test is not defined");
	}
	
}
