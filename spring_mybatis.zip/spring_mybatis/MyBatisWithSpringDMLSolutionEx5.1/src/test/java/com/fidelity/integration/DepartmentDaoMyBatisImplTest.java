package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.OptionalInt;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.fidelity.business.Department;
import com.fidelity.business.Employee;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("classpath:beans.xml")
@Transactional
class DepartmentDaoMyBatisImplTest {

	@Autowired
	DepartmentDaoMyBatisImpl dao;

	@Test
	void testGetAllDepartments() {
		List<Department> departments = dao.getAllDepartments();

		assertNotNull(departments);
		
		assertEquals(4, departments.size());

		for (Department department : departments) {
			assertNotNull(department);
			assertNotNull(department.getName());
		}
		assertTrue(departments.contains(new Department(10, "ACCOUNTING", "NEW YORK")));
	}

	@Test
	void testGetAllDepartmentsAndEmployees() {
		// The mapper returns the data in id order. If it didn't, this would be a bit harder to write
		Employee emp7782 = new Employee(7782, "CLARK", "MANAGER", 7839, LocalDate.of(1981, 6, 9), 2450.0, 0.0, 10);
		Employee emp7839 = new Employee(7839, "KING", "PRESIDENT", 0, LocalDate.of(1981, 11, 17), 5000.0, 0.0, 10);
		Employee emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, LocalDate.of(1982, 1, 23), 1300.0, 0.0, 10);

		Department expected = new Department(10, "ACCOUNTING", "NEW YORK", Arrays.asList(emp7782, emp7839, emp7934));
		
		List<Department> departments = dao.getAllDepartmentsAndEmployees();
		
		assertNotNull(departments);
		assertTrue(departments.size() > 0);
		
		for (Department department : departments) {
			assertNotNull(department);
			List<Employee> employees = department.getEmployees();
			assertNotNull(employees);
			for (Employee employee : employees) {
				assertNotNull(employee);
				assertNotNull(employee.getId());
			}
		}
		assertTrue(departments.contains(expected));
	}

	@Test
	void testInsertDepartment() {
		List<Department> departments = dao.getAllDepartments();
		assertNotNull(departments);
		int expected = departments.size() + 1;		// expecting the size to be increased by 1

		// new department
		Department newDept = new Department(findMaxDepartmentId(departments) + 10, "Test Dept", "Test Loc");		

		assertTrue(dao.insertDepartment(newDept));

		// query for the number of departments after insert
		departments = dao.getAllDepartments();
		int actual = departments.size();

		// verify the number of department records increased by 1
		assertEquals(expected, actual);
		assertTrue(departments.contains(newDept));
	}

	private int findMaxDepartmentId(List<Department> depts) {
		OptionalInt maxDept = depts.stream()
				.mapToInt(Department::getId)
				.max();
		return maxDept.orElse(0);
	}

	@Test
	void testUpdateDepartment() {
		List<Department> departments = dao.getAllDepartments();
		int expected = departments.size();

		Department oldDept = departments.get(0);
		if ("Updated".equals(oldDept.getName())) {
			fail("Department name already has test value");
		}

		Department newDept = new Department(oldDept.getId(), "Updated", oldDept.getLocation());

		assertTrue(dao.updateDepartment(newDept));
		
		departments = dao.getAllDepartments();
		assertTrue(departments.contains(newDept));
		assertEquals(expected, departments.size());
	}

}
