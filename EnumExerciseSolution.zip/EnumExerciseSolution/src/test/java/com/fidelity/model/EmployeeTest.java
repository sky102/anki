package com.fidelity.model;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

class EmployeeTest {

	// 10.1 Using BigDecimal, so must set scale consistently
	@Test
	void testScaleIsSetCorrectly() {
		Employee emp = new Employee(1, "KENT", "CLERK", 0, "17-DEC-1980", new BigDecimal("100"), 
				new BigDecimal("200"), 10);
		assertNotEquals(new BigDecimal("100"), emp.getSalary(), "Expect salary to be forced to 2 decimal places");
		assertEquals(new BigDecimal("100.00"), emp.getSalary(), "Expect salary to be forced to 2 decimal places");
		assertNotEquals(new BigDecimal("200"), emp.getComm(), "Expect comm to be forced to 2 decimal places");
		assertEquals(new BigDecimal("200.00"), emp.getComm(), "Expect comm to be forced to 2 decimal places");
	}

	@Test
	void testPerfReviewResultIsSetCorrectly() {
		Employee emp = new Employee(1, "KENT", "CLERK", 0, "17-DEC-1980", new BigDecimal("100"), 
				new BigDecimal("200"), 10, PerfReviewResult.ABOVE);
		assertEquals(PerfReviewResult.ABOVE, emp.getPerfReviewResult());
	}
}
