package com.fidelity.integration;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.Employee;
import com.fidelity.model.PerfReviewResult;

public class EmployeeDaoOracleImpl {
    private final Logger logger = LoggerFactory.getLogger(EmployeeDaoOracleImpl.class);
	
	private Connection conn;

	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// Since this is now called separately, throwing an exception will probably not hide one
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}

	private Connection getConnection() {
		if (conn == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");

				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				logger.error("Cannot read db.properties", e);
				throw new DatabaseException("Cannot read db.properties", e);
			} catch (SQLException e) {
				logger.error("Cannot connect", e);
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}

	public List<Employee> queryAllEmployees() {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, "
				+ "          sal, comm, deptno, perf_rev_result "
				+ "   FROM emp";
		List<Employee> emps = new ArrayList<>();
		// 7.4 #4
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryAllEmployees: {}", sql, e);
			throw new DatabaseException("Cannot execute queryAllEmployees", e);
		}
		return emps;
	}

	private List<Employee> getAndHandleResults(PreparedStatement stmt) throws SQLException {
		List<Employee> emps = new ArrayList<>();
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			int empNumber = rs.getInt("empno");
			String empName = rs.getString("ename");
			String job = rs.getString("job");
			Integer mgrNumber = rs.getInt("mgr");
			// Optional 10.1 #2
			if (rs.wasNull()) {
				mgrNumber = null;
			}
			String hireDate = rs.getString("hiredate");
			BigDecimal sal = rs.getBigDecimal("sal");
			BigDecimal comm = rs.getBigDecimal("comm");
			int deptNumber = rs.getInt("deptno");
			PerfReviewResult perfReviewResult = PerfReviewResult.of(rs.getInt("perf_rev_result"));
			// BONUS: Convert perf_rev_result column to PerfReviewResult only if column value is not null
			// PerfReviewResult perfReviewResult = null;
			// int perfRevResultFromDb = rs.getInt("perf_rev_result");
			// if (perfRevResultFromDb != 0) { // don't try to convert if column value is null
			// 	perfReviewResult = PerfReviewResult.of(perfRevResultFromDb);
			// }
			Employee emp = new Employee(empNumber, empName, job, mgrNumber, hireDate, sal, 
					                    comm, deptNumber, perfReviewResult);
			emps.add(emp);
		}
		return emps;
	}

	public void insertEmployee(Employee emp) {
		String sql = "INSERT INTO emp (ename, job, mgr, hiredate, sal, comm, deptno, perf_rev_result, empno) "
				+ "            VALUES (?, ?, ?, TO_DATE(?, 'DD-MON-YYYY'), ?, ?, ?, ?, ?)";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, emp.getEmpName());
			stmt.setString(2, emp.getJob());
			if (emp.getMgrNumber() == null) {
				stmt.setNull(3, java.sql.Types.NUMERIC);
			} else {
				stmt.setInt(3, emp.getMgrNumber());
			}
			stmt.setString(4, emp.getHireDate());
			stmt.setBigDecimal(5, emp.getSalary());
			stmt.setBigDecimal(6, emp.getComm());
			stmt.setInt(7, emp.getDeptNumber());
			stmt.setInt(8, emp.getPerfReviewResult().getCode());
			// BONUS: handle null perfReviewResult
			// if (emp.getPerfReviewResult() == null) {
			// 	stmt.setNull(8, java.sql.Types.INTEGER);
			// } else {
			// 	stmt.setInt(8, emp.getPerfReviewResult().getCode());
			// }
			stmt.setInt(9, emp.getEmpNumber());
			stmt.execute();
		} catch (SQLException e) {
			logger.error("Cannot execute insertEmployee: {} for {}", sql, emp, e);
			throw new DatabaseException("Cannot insert employee", e);
		}
	}

	public void deleteEmployee(int empNumber) {
		List<Integer> empNumbers = new ArrayList<>();
		empNumbers.add(empNumber);
		deleteEmployee(empNumbers);
	}

	public void deleteEmployee(List<Integer> empNumbers) {
		String sql = "DELETE FROM emp "
				   + "WHERE empno = ?";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			for (int empNumber : empNumbers) {
				stmt.setInt(1, empNumber);
				stmt.addBatch();
			}
			stmt.executeBatch();
		} catch (SQLException e) {
			logger.error("Cannot execute deleteEmployee: {} for {}", sql, empNumbers, e);
			throw new DatabaseException("Cannot delete employee", e);
		}
	}

}
