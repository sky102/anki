package com.fidelity.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Employee {
	private int empNumber;
	private String empName;
	private String job;
	private Integer mgrNumber;
	private String hireDate;
	private BigDecimal salary;
	private BigDecimal comm;
	private int deptNumber;
	private PerfReviewResult perfReviewResult;

	// 10.1 #1 ensure BigDecimal always same scale
	// Optional 10.1 #2 changing manager to Integer requires no special processing, but updated auto-generated methods
	public Employee(int empNumber, String empName, String job, Integer mgrNumber, String hireDate, BigDecimal salary,
			BigDecimal comm, int deptNumber) {
		super();
		this.empNumber = empNumber;
		this.empName = empName;
		this.job = job;
		this.mgrNumber = mgrNumber;
		this.hireDate = hireDate;
		if (salary != null) {
			this.salary = salary.setScale(2, RoundingMode.HALF_UP);
		}
		if (comm != null) {
			this.comm = comm.setScale(2, RoundingMode.HALF_UP);
		}
		this.deptNumber = deptNumber;
	}

	// All methods auto-generated from here

	public Employee(int empNumber, String empName, String job, Integer mgrNumber, String hireDate, BigDecimal salary,
			BigDecimal comm, int deptNumber, PerfReviewResult perfReviewResult) {
		this(empNumber, empName, job, mgrNumber, hireDate, salary, comm, deptNumber);
		this.perfReviewResult = perfReviewResult;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((comm == null) ? 0 : comm.hashCode());
		result = prime * result + deptNumber;
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		result = prime * result + empNumber;
		result = prime * result + ((hireDate == null) ? 0 : hireDate.hashCode());
		result = prime * result + ((job == null) ? 0 : job.hashCode());
		result = prime * result + ((mgrNumber == null) ? 0 : mgrNumber.hashCode());
		result = prime * result + ((perfReviewResult == null) ? 0 : perfReviewResult.hashCode());
		result = prime * result + ((salary == null) ? 0 : salary.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (comm == null) {
			if (other.comm != null)
				return false;
		} else if (!comm.equals(other.comm))
			return false;
		if (deptNumber != other.deptNumber)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (empNumber != other.empNumber)
			return false;
		if (hireDate == null) {
			if (other.hireDate != null)
				return false;
		} else if (!hireDate.equals(other.hireDate))
			return false;
		if (job == null) {
			if (other.job != null)
				return false;
		} else if (!job.equals(other.job))
			return false;
		if (mgrNumber == null) {
			if (other.mgrNumber != null)
				return false;
		} else if (!mgrNumber.equals(other.mgrNumber))
			return false;
		if (perfReviewResult != other.perfReviewResult)
			return false;
		if (salary == null) {
			if (other.salary != null)
				return false;
		} else if (!salary.equals(other.salary))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [empNumber=" + empNumber + ", empName=" + empName + ", job=" + job + ", mgrNumber=" + mgrNumber
				+ ", hireDate=" + hireDate + ", salary=" + salary + ", comm=" + comm + ", deptNumber=" + deptNumber
				+ ", perfReviewResult=" + perfReviewResult + "]";
	}

	public int getEmpNumber() {
		return empNumber;
	}

	public String getEmpName() {
		return empName;
	}

	public String getJob() {
		return job;
	}

	public Integer getMgrNumber() {
		return mgrNumber;
	}

	public String getHireDate() {
		return hireDate;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public BigDecimal getComm() {
		return comm;
	}

	public int getDeptNumber() {
		return deptNumber;
	}

	public PerfReviewResult getPerfReviewResult() {
		return perfReviewResult;
	}

	public void setPerfReviewResult(PerfReviewResult perfReviewResult) {
		this.perfReviewResult = perfReviewResult;
	}

}
