import { Component, OnInit } from '@angular/core';

import { Book } from '../../models/book';
import { BookService } from '../../book.service';

@Component({
    selector: 'app-book-page',
    templateUrl: './book-page.component.html',
    styleUrls: ['./book-page.component.css']
})
export class BookPageComponent implements OnInit {

    books: Book[] = [];

    constructor(private bookService: BookService) { }

    ngOnInit() {
        this.getBooks();
    }

    addBook(book: Book) {
        this.bookService.addBook(book)
            .subscribe(() => this.getBooks());
    }

    getBooks() {
        this.bookService.getBooks()
            .subscribe(data => this.books = data);
    }
}
