import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { Book } from './models/book';

@Injectable({
    providedIn: 'root'
})
export class BookService {

    books: Book[] = [{
        title: 'The Lord of the Rings',
        author: 'J R R Tolkien',
        cover: '',
        bookId: 1
    }, {
        title: 'The Left Hand of Darkness',
        author: 'Ursula K Le Guin',
        cover: '',
        bookId: 2
    }];

    constructor() { }

    getBooks(): Observable<Book[]> {
        return of(this.books);
    }

    addBook(book: Book): Observable<Book> {
        this.books.push(book);
        return of(book);
    }
}
