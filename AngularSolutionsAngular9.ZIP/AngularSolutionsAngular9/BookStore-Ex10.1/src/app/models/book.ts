export class Book {
    constructor(
        public title: string,
        public author: string,
        public cover: string,
        public bookId: number) { }
}
